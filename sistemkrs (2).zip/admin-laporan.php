<?php
require_once __DIR__ . '/config/config.php';
requireLogin();

// Check if user is admin
$user_role = getUserRole();
if ($user_role !== 'admin') {
    header('Location: dashboard.php');
    exit();
}

$database = new Database();
$conn = $database->getConnection();

// Get filter parameters
$semester = $_GET['semester'] ?? '';
$tahun_ajaran = $_GET['tahun_ajaran'] ?? '';
$jurusan = $_GET['jurusan'] ?? '';
$program_studi = $_GET['program_studi'] ?? '';

// Build where conditions
$where_conditions = [];
$params = [];

if (!empty($semester)) {
    $where_conditions[] = "k.semester = :semester";
    $params[':semester'] = $semester;
}

if (!empty($tahun_ajaran)) {
    $where_conditions[] = "k.tahun_ajaran = :tahun_ajaran";
    $params[':tahun_ajaran'] = $tahun_ajaran;
}

if (!empty($jurusan)) {
    $where_conditions[] = "m.jurusan = :jurusan";
    $params[':jurusan'] = $jurusan;
}

if (!empty($program_studi)) {
    $where_conditions[] = "m.program_studi = :program_studi";
    $params[':program_studi'] = $program_studi;
}

$where_clause = !empty($where_conditions) ? 'WHERE ' . implode(' AND ', $where_conditions) : '';

// Get KRS statistics
try {
    $stats_query = "SELECT 
                        COUNT(*) as total_krs,
                        SUM(CASE WHEN krs.status = 'pending' THEN 1 ELSE 0 END) as pending,
                        SUM(CASE WHEN krs.status = 'disetujui' THEN 1 ELSE 0 END) as disetujui,
                        SUM(CASE WHEN krs.status = 'ditolak' THEN 1 ELSE 0 END) as ditolak,
                        SUM(mk.sks) as total_sks
                    FROM krs 
                    JOIN kelas k ON krs.id_kelas = k.id_kelas
                    JOIN mata_kuliah mk ON k.id_matakuliah = mk.id_matakuliah
                    JOIN mahasiswa m ON krs.id_mahasiswa = m.id_mahasiswa
                    $where_clause";
    $stats_stmt = $conn->prepare($stats_query);
    foreach ($params as $key => $value) {
        $stats_stmt->bindValue($key, $value);
    }
    $stats_stmt->execute();
    $krs_stats = $stats_stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $krs_stats = ['total_krs' => 0, 'pending' => 0, 'disetujui' => 0, 'ditolak' => 0, 'total_sks' => 0];
}

// Get mahasiswa statistics
try {
    $mahasiswa_stats_query = "SELECT 
                                COUNT(*) as total_mahasiswa,
                                SUM(CASE WHEN status = 'aktif' THEN 1 ELSE 0 END) as aktif,
                                SUM(CASE WHEN status = 'nonaktif' THEN 1 ELSE 0 END) as nonaktif,
                                SUM(CASE WHEN status = 'cuti' THEN 1 ELSE 0 END) as cuti,
                                SUM(CASE WHEN status = 'lulus' THEN 1 ELSE 0 END) as lulus
                              FROM mahasiswa";
    if (!empty($jurusan) || !empty($program_studi)) {
        $mahasiswa_where = [];
        if (!empty($jurusan)) {
            $mahasiswa_where[] = "jurusan = :jurusan";
        }
        if (!empty($program_studi)) {
            $mahasiswa_where[] = "program_studi = :program_studi";
        }
        $mahasiswa_stats_query .= " WHERE " . implode(' AND ', $mahasiswa_where);
    }
    
    $mahasiswa_stats_stmt = $conn->prepare($mahasiswa_stats_query);
    if (!empty($jurusan)) {
        $mahasiswa_stats_stmt->bindValue(':jurusan', $jurusan);
    }
    if (!empty($program_studi)) {
        $mahasiswa_stats_stmt->bindValue(':program_studi', $program_studi);
    }
    $mahasiswa_stats_stmt->execute();
    $mahasiswa_stats = $mahasiswa_stats_stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $mahasiswa_stats = ['total_mahasiswa' => 0, 'aktif' => 0, 'nonaktif' => 0, 'cuti' => 0, 'lulus' => 0];
}

// Get detailed KRS report
try {
    $detail_query = "SELECT 
                        m.nim, m.nama as nama_mahasiswa, m.jurusan, m.program_studi,
                        mk.kode_matakuliah, mk.nama_matakuliah, mk.sks,
                        k.nama_kelas, k.semester, k.tahun_ajaran,
                        d.nama_dosen, krs.status, krs.created_at
                     FROM krs 
                     JOIN kelas k ON krs.id_kelas = k.id_kelas
                     JOIN mata_kuliah mk ON k.id_matakuliah = mk.id_matakuliah
                     JOIN mahasiswa m ON krs.id_mahasiswa = m.id_mahasiswa
                     LEFT JOIN dosen d ON k.id_dosen = d.id_dosen
                     $where_clause
                     ORDER BY m.nim, mk.nama_matakuliah";
    $detail_stmt = $conn->prepare($detail_query);
    foreach ($params as $key => $value) {
        $detail_stmt->bindValue($key, $value);
    }
    $detail_stmt->execute();
    $krs_detail = $detail_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $krs_detail = [];
}

// Get filter options
try {
    $semester_query = "SELECT DISTINCT semester FROM kelas ORDER BY semester";
    $semester_stmt = $conn->prepare($semester_query);
    $semester_stmt->execute();
    $semester_list = $semester_stmt->fetchAll(PDO::FETCH_COLUMN);

    $tahun_query = "SELECT DISTINCT tahun_ajaran FROM kelas ORDER BY tahun_ajaran DESC";
    $tahun_stmt = $conn->prepare($tahun_query);
    $tahun_stmt->execute();
    $tahun_list = $tahun_stmt->fetchAll(PDO::FETCH_COLUMN);

    $jurusan_query = "SELECT DISTINCT jurusan FROM mahasiswa ORDER BY jurusan";
    $jurusan_stmt = $conn->prepare($jurusan_query);
    $jurusan_stmt->execute();
    $jurusan_list = $jurusan_stmt->fetchAll(PDO::FETCH_COLUMN);

    $prodi_query = "SELECT DISTINCT program_studi FROM mahasiswa ORDER BY program_studi";
    $prodi_stmt = $conn->prepare($prodi_query);
    $prodi_stmt->execute();
    $prodi_list = $prodi_stmt->fetchAll(PDO::FETCH_COLUMN);
} catch (PDOException $e) {
    $semester_list = $tahun_list = $jurusan_list = $prodi_list = [];
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan KRS - <?php echo APP_NAME; ?></title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(310deg, #f0f2f5 0%, #fcfcfc 100%);
            font-family: 'Open Sans', sans-serif;
        }
        .card {
            background: #fff;
            border-radius: 1rem;
            box-shadow: 0 20px 27px 0 rgba(0, 0, 0, 0.05);
            border: 0;
        }
        .form-input {
            border: 1px solid #e0e0e0;
            border-radius: 10px;
            padding: 12px 16px;
            transition: all 0.3s ease;
        }
        .form-input:focus {
            border-color: #7928ca;
            box-shadow: 0 0 0 3px rgba(121, 40, 202, 0.1);
            outline: none;
        }
        @media print {
            .no-print { display: none !important; }
            body { background: white !important; }
            .card { box-shadow: none !important; }
        }
    </style>
</head>
<body class="bg-gray-50">
    <div class="container mx-auto px-4 py-8">
        <!-- Header -->
        <div class="card mb-6 no-print">
            <div class="p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <h1 class="text-2xl font-bold text-gray-800">Laporan KRS</h1>
                        <p class="text-gray-600">Laporan Kartu Rencana Studi Mahasiswa</p>
                    </div>
                    <div class="flex gap-3">
                        <button onclick="window.print()" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
                            <i class="fas fa-print mr-2"></i>Cetak
                        </button>
                        <a href="dashboard-admin.php" class="bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700">
                            <i class="fas fa-arrow-left mr-2"></i>Kembali
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Filters -->
        <div class="card mb-6 no-print">
            <div class="p-6">
                <h3 class="text-lg font-semibold text-gray-800 mb-4">Filter Laporan</h3>
                <form method="GET" class="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Semester</label>
                        <select name="semester" class="form-input w-full">
                            <option value="">Semua Semester</option>
                            <?php foreach ($semester_list as $sem): ?>
                                <option value="<?php echo $sem; ?>" <?php echo ($semester == $sem) ? 'selected' : ''; ?>>
                                    <?php echo $sem; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Tahun Ajaran</label>
                        <select name="tahun_ajaran" class="form-input w-full">
                            <option value="">Semua Tahun</option>
                            <?php foreach ($tahun_list as $tahun): ?>
                                <option value="<?php echo $tahun; ?>" <?php echo ($tahun_ajaran == $tahun) ? 'selected' : ''; ?>>
                                    <?php echo $tahun; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Jurusan</label>
                        <select name="jurusan" class="form-input w-full">
                            <option value="">Semua Jurusan</option>
                            <?php foreach ($jurusan_list as $jur): ?>
                                <option value="<?php echo $jur; ?>" <?php echo ($jurusan == $jur) ? 'selected' : ''; ?>>
                                    <?php echo $jur; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Program Studi</label>
                        <select name="program_studi" class="form-input w-full">
                            <option value="">Semua Program Studi</option>
                            <?php foreach ($prodi_list as $prodi): ?>
                                <option value="<?php echo $prodi; ?>" <?php echo ($program_studi == $prodi) ? 'selected' : ''; ?>>
                                    <?php echo $prodi; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="md:col-span-4">
                        <button type="submit" class="bg-purple-600 text-white px-6 py-2 rounded-lg hover:bg-purple-700">
                            <i class="fas fa-filter mr-2"></i>Filter
                        </button>
                        <a href="admin-laporan.php" class="ml-2 bg-gray-200 text-gray-700 px-6 py-2 rounded-lg hover:bg-gray-300">
                            <i class="fas fa-times mr-2"></i>Reset
                        </a>
                    </div>
                </form>
            </div>
        </div>

        <!-- Statistics Cards -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
            <div class="card">
                <div class="p-6">
                    <div class="flex items-center">
                        <div class="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                            <i class="fas fa-clipboard-list text-blue-600 text-xl"></i>
                        </div>
                        <div class="ml-4">
                            <p class="text-sm font-medium text-gray-600">Total KRS</p>
                            <p class="text-2xl font-bold text-gray-900"><?php echo $krs_stats['total_krs']; ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="p-6">
                    <div class="flex items-center">
                        <div class="w-12 h-12 bg-yellow-100 rounded-xl flex items-center justify-center">
                            <i class="fas fa-clock text-yellow-600 text-xl"></i>
                        </div>
                        <div class="ml-4">
                            <p class="text-sm font-medium text-gray-600">Pending</p>
                            <p class="text-2xl font-bold text-gray-900"><?php echo $krs_stats['pending']; ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="p-6">
                    <div class="flex items-center">
                        <div class="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                            <i class="fas fa-check text-green-600 text-xl"></i>
                        </div>
                        <div class="ml-4">
                            <p class="text-sm font-medium text-gray-600">Disetujui</p>
                            <p class="text-2xl font-bold text-gray-900"><?php echo $krs_stats['disetujui']; ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="p-6">
                    <div class="flex items-center">
                        <div class="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center">
                            <i class="fas fa-times text-red-600 text-xl"></i>
                        </div>
                        <div class="ml-4">
                            <p class="text-sm font-medium text-gray-600">Ditolak</p>
                            <p class="text-2xl font-bold text-gray-900"><?php echo $krs_stats['ditolak']; ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Mahasiswa Statistics -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 mb-6">
            <div class="card">
                <div class="p-6">
                    <div class="text-center">
                        <div class="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center mx-auto mb-2">
                            <i class="fas fa-users text-purple-600 text-xl"></i>
                        </div>
                        <p class="text-sm font-medium text-gray-600">Total Mahasiswa</p>
                        <p class="text-xl font-bold text-gray-900"><?php echo $mahasiswa_stats['total_mahasiswa']; ?></p>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="p-6">
                    <div class="text-center">
                        <div class="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center mx-auto mb-2">
                            <i class="fas fa-user-check text-green-600 text-xl"></i>
                        </div>
                        <p class="text-sm font-medium text-gray-600">Aktif</p>
                        <p class="text-xl font-bold text-gray-900"><?php echo $mahasiswa_stats['aktif']; ?></p>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="p-6">
                    <div class="text-center">
                        <div class="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center mx-auto mb-2">
                            <i class="fas fa-user-times text-red-600 text-xl"></i>
                        </div>
                        <p class="text-sm font-medium text-gray-600">Non-aktif</p>
                        <p class="text-xl font-bold text-gray-900"><?php echo $mahasiswa_stats['nonaktif']; ?></p>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="p-6">
                    <div class="text-center">
                        <div class="w-12 h-12 bg-yellow-100 rounded-xl flex items-center justify-center mx-auto mb-2">
                            <i class="fas fa-user-clock text-yellow-600 text-xl"></i>
                        </div>
                        <p class="text-sm font-medium text-gray-600">Cuti</p>
                        <p class="text-xl font-bold text-gray-900"><?php echo $mahasiswa_stats['cuti']; ?></p>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="p-6">
                    <div class="text-center">
                        <div class="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center mx-auto mb-2">
                            <i class="fas fa-graduation-cap text-blue-600 text-xl"></i>
                        </div>
                        <p class="text-sm font-medium text-gray-600">Lulus</p>
                        <p class="text-xl font-bold text-gray-900"><?php echo $mahasiswa_stats['lulus']; ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Detailed Report -->
        <div class="card">
            <div class="p-6 border-b">
                <h3 class="text-lg font-semibold text-gray-800">Detail Laporan KRS</h3>
                <p class="text-gray-600">Data lengkap KRS mahasiswa berdasarkan filter yang dipilih</p>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">No</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">NIM</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nama Mahasiswa</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Program Studi</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Mata Kuliah</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Kelas</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Dosen</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">SKS</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tanggal</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php if (empty($krs_detail)): ?>
                            <tr>
                                <td colspan="10" class="px-6 py-4 text-center text-gray-500">Tidak ada data KRS</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($krs_detail as $index => $krs): ?>
                                <tr class="hover:bg-gray-50">
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo $index + 1; ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo htmlspecialchars($krs['nim']); ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo htmlspecialchars($krs['nama_mahasiswa']); ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        <?php echo htmlspecialchars($krs['program_studi']); ?>
                                        <br><small><?php echo htmlspecialchars($krs['jurusan']); ?></small>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                        <?php echo htmlspecialchars($krs['kode_matakuliah']); ?> - <?php echo htmlspecialchars($krs['nama_matakuliah']); ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                        <?php echo htmlspecialchars($krs['nama_kelas']); ?>
                                        <br><small><?php echo htmlspecialchars($krs['semester']); ?> - <?php echo htmlspecialchars($krs['tahun_ajaran']); ?></small>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo htmlspecialchars($krs['nama_dosen'] ?: '-'); ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo $krs['sks']; ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <span class="px-2 py-1 text-xs font-semibold rounded-full 
                                            <?php 
                                            switch($krs['status']) {
                                                case 'pending': echo 'bg-yellow-100 text-yellow-800'; break;
                                                case 'disetujui': echo 'bg-green-100 text-green-800'; break;
                                                case 'ditolak': echo 'bg-red-100 text-red-800'; break;
                                                default: echo 'bg-gray-100 text-gray-800';
                                            }
                                            ?>">
                                            <?php echo ucfirst($krs['status']); ?>
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        <?php echo date('d/m/Y', strtotime($krs['created_at'])); ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>
