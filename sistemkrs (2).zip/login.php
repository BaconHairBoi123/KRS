<?php
require_once __DIR__ . '/config/config.php';

// Redirect if already logged in
if (isLoggedIn()) {
    $role = getUserRole();
    switch ($role) {
        case 'admin':
            redirect('dashboard-admin.php');
            break;
        case 'dosen':
            redirect('dashboard-dosen.php');
            break;
        case 'mahasiswa':
        default:
            redirect('dashboard.php');
            break;
    }
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    
    if (empty($username) || empty($password)) {
        $error = 'Username dan password harus diisi';
    } else {
        $database = new Database();
        $conn = $database->getConnection();
        
        try {
            // Try login as mahasiswa first
            $query = "SELECT id_mahasiswa as id, nim as username, nama, password, 'mahasiswa' as role 
                     FROM mahasiswa WHERE nim = :username AND status = 'aktif'";
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':username', $username);
            $stmt->execute();
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // If not found as mahasiswa, try as dosen
            if (!$user) {
                $query = "SELECT id_dosen as id, nidn as username, nama_dosen as nama, password, 'dosen' as role 
                         FROM dosen WHERE nidn = :username AND status = 'aktif'";
                $stmt = $conn->prepare($query);
                $stmt->bindParam(':username', $username);
                $stmt->execute();
                $user = $stmt->fetch(PDO::FETCH_ASSOC);
            }
            
            // If not found as dosen, try as admin
            if (!$user) {
                $query = "SELECT id_admin as id, username, nama, password, 'admin' as role 
                         FROM admin WHERE username = :username AND status = 'aktif'";
                $stmt = $conn->prepare($query);
                $stmt->bindParam(':username', $username);
                $stmt->execute();
                $user = $stmt->fetch(PDO::FETCH_ASSOC);
            }
            
            if ($user && password_verify($password, $user['password'])) {
                // Set session variables
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['nama'] = $user['nama'];
                $_SESSION['role'] = $user['role'];
                $_SESSION['nim'] = $user['username']; // For compatibility
                
                // Redirect based on role
                switch ($user['role']) {
                    case 'admin':
                        redirect('dashboard-admin.php');
                        break;
                    case 'dosen':
                        redirect('dashboard-dosen.php');
                        break;
                    case 'mahasiswa':
                    default:
                        redirect('dashboard.php');
                        break;
                }
            } else {
                $error = 'Username atau password salah';
            }
        } catch (Exception $e) {
            $error = 'Terjadi kesalahan sistem: ' . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - <?php echo APP_NAME; ?></title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(310deg, #7928ca 0%, #ff0080 100%);
            font-family: 'Open Sans', sans-serif;
        }
        .glass-card {
            background: rgba(255, 255, 255, 0.25);
            backdrop-filter: blur(42px);
            border-radius: 1rem;
            border: 1px solid rgba(255, 255, 255, 0.18);
        }
        .form-input {
            background: rgba(255, 255, 255, 0.2);
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 10px;
            padding: 12px 16px;
            color: white;
            transition: all 0.3s ease;
        }
        .form-input::placeholder {
            color: rgba(255, 255, 255, 0.7);
        }
        .form-input:focus {
            background: rgba(255, 255, 255, 0.3);
            border-color: rgba(255, 255, 255, 0.5);
            outline: none;
            box-shadow: 0 0 0 3px rgba(255, 255, 255, 0.1);
        }
        .password-toggle {
            position: absolute;
            right: 12px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: rgba(255, 255, 255, 0.7);
            transition: color 0.3s ease;
        }
        .password-toggle:hover {
            color: white;
        }
    </style>
</head>
<body class="min-h-screen flex items-center justify-center p-4">
    <div class="glass-card w-full max-w-md p-8">
        <!-- Logo -->
        <div class="text-center mb-8">
            <div class="w-20 h-20 bg-white bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-4">
                <i class="fas fa-graduation-cap text-white text-3xl"></i>
            </div>
            <h1 class="text-2xl font-bold text-white mb-2">Sistem KRS</h1>
            <p class="text-white text-opacity-80">Politeknik Negeri Jakarta</p>
        </div>

        <!-- Login Form -->
        <form method="POST" class="space-y-6">
            <?php if ($error): ?>
                <div class="bg-red-500 bg-opacity-20 border border-red-400 text-white px-4 py-3 rounded-lg">
                    <div class="flex items-center">
                        <i class="fas fa-exclamation-circle mr-2"></i>
                        <span><?php echo $error; ?></span>
                    </div>
                </div>
            <?php endif; ?>

            <div>
                <label for="username" class="block text-white text-sm font-medium mb-2">
                    <i class="fas fa-user mr-2"></i>Username (NIM/NIDN)
                </label>
                <input type="text" id="username" name="username" required 
                       class="form-input w-full" placeholder="Masukkan NIM atau NIDN">
            </div>

            <div>
                <label for="password" class="block text-white text-sm font-medium mb-2">
                    <i class="fas fa-lock mr-2"></i>Password
                </label>
                <div class="relative">
                    <input type="password" id="password" name="password" required 
                           class="form-input w-full pr-12" placeholder="Masukkan password">
                    <span class="password-toggle" onclick="togglePassword('password')">
                        <i class="fas fa-eye" id="password-eye"></i>
                    </span>
                </div>
            </div>

            <button type="submit" class="w-full bg-white bg-opacity-20 hover:bg-opacity-30 text-white font-semibold py-3 px-4 rounded-lg transition-all duration-300 border border-white border-opacity-30">
                <i class="fas fa-sign-in-alt mr-2"></i>
                Masuk
            </button>
        </form>

        <!-- Register Links -->
        <div class="mt-8 text-center">
            <p class="text-white text-opacity-80 mb-4">Belum punya akun?</p>
            <div class="space-y-2">
                <a href="register.php" class="block w-full bg-transparent border border-white border-opacity-30 text-white py-2 px-4 rounded-lg hover:bg-white hover:bg-opacity-10 transition-all duration-300">
                    <i class="fas fa-user-plus mr-2"></i>
                    Daftar sebagai Mahasiswa
                </a>
                <a href="register-dosen.php" class="block w-full bg-transparent border border-white border-opacity-30 text-white py-2 px-4 rounded-lg hover:bg-white hover:bg-opacity-10 transition-all duration-300">
                    <i class="fas fa-chalkboard-teacher mr-2"></i>
                    Daftar sebagai Dosen
                </a>
            </div>
        </div>
    </div>

    <script>
        function togglePassword(inputId) {
            const input = document.getElementById(inputId);
            const eye = document.getElementById(inputId + '-eye');
            
            if (input.type === 'password') {
                input.type = 'text';
                eye.classList.remove('fa-eye');
                eye.classList.add('fa-eye-slash');
            } else {
                input.type = 'password';
                eye.classList.remove('fa-eye-slash');
                eye.classList.add('fa-eye');
            }
        }
    </script>
</body>
</html>
