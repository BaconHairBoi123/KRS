<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/includes/auth.php';

// Redirect if already logged in
if (isLoggedIn()) {
    redirect('dashboard.php');
}

$success = '';
$error = '';

// Program studi options based on jurusan
$program_studi_options = [
    'Akuntansi' => [
        'D2 Administrasi Perpajakan',
        'D3 Akuntansi',
        'D4 Akuntansi Manajerial',
        'D4 Akuntansi Perpajakan'
    ],
    'Administrasi Bisnis' => [
        'D2 Manajemen Operasional Bisnis Digital',
        'D3 Administrasi Bisnis',
        'D4 Manajemen Bisnis Internasional',
        'D4 Bisnis Digital',
        'D4 Bahasa Inggris untuk Komunikasi Bisnis & Profesional'
    ],
    'Pariwisata' => [
        'S2 Terapan Perencanaan Pariwisata',
        'D4 Manajemen Bisnis Pariwisata',
        'D3 Perhotelan',
        'D3 Usaha Perjalanan Wisata'
    ],
    'Teknik Sipil' => [
        'D2 Fondasi, Beton, & Pengaspalan Jalan',
        'D3 Teknik Sipil',
        'D4 Manajemen Proyek Konstruksi',
        'D4 Teknologi Rekayasa Konstruksi Bangunan Gedung',
        'D4 Teknologi Rekayasa Konstruksi Bangunan Air'
    ],
    'Teknik Mesin' => [
        'D2 Teknik Manufaktur Mesin',
        'D3 Teknik Mesin',
        'D3 Teknik Pendingin dan Tata Udara',
        'D4 Teknologi Rekayasa Utilitas',
        'D4 Rekayasa Perancangan Mekanik'
    ],
    'Teknik Elektro' => [
        'D2 Instalasi dan Pemeliharaan Kabel Bertegangan Rendah',
        'D3 Teknik Listrik',
        'D4 Teknik Otomasi',
        'D4 Teknologi Rekayasa Energi Terbarukan'
    ],
    'Teknologi Informasi' => [
        'D2 Administrasi Jaringan Komputer',
        'D3 Manajemen Informatika',
        'D4 Teknologi Rekayasa Perangkat Lunak'
    ]
];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nim = trim($_POST['nim']);
    $nama = trim($_POST['nama']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $tanggal_lahir = $_POST['tanggal_lahir'];
    $jenis_kelamin = $_POST['jenis_kelamin'];
    $alamat = trim($_POST['alamat']);
    $nomor_telepon = trim($_POST['nomor_telepon']);
    $jurusan = $_POST['jurusan'];
    $program_studi = $_POST['program_studi'];
    $angkatan = $_POST['angkatan'];
    
    // Validation
    if (empty($nim) || empty($nama) || empty($email) || empty($password)) {
        $error = 'Semua field yang wajib harus diisi';
    } elseif ($password !== $confirm_password) {
        $error = 'Password dan konfirmasi password tidak sama';
    } elseif (strlen($password) < 6) {
        $error = 'Password minimal 6 karakter';
    } else {
        $database = new Database();
        $conn = $database->getConnection();
        
        try {
            // Check if NIM already exists
            $check_query = "SELECT nim FROM mahasiswa WHERE nim = :nim";
            $check_stmt = $conn->prepare($check_query);
            $check_stmt->bindParam(':nim', $nim);
            $check_stmt->execute();
            
            if ($check_stmt->fetch()) {
                $error = 'NIM sudah terdaftar';
            } else {
                // Insert new mahasiswa
                $query = "INSERT INTO mahasiswa (nim, nama, email, password, tanggal_lahir, jenis_kelamin, alamat, nomor_telepon, jurusan, program_studi, angkatan, semester_aktif, status) 
                         VALUES (:nim, :nama, :email, :password, :tanggal_lahir, :jenis_kelamin, :alamat, :nomor_telepon, :jurusan, :program_studi, :angkatan, 1, 'aktif')";
                $stmt = $conn->prepare($query);
                $stmt->bindParam(':nim', $nim);
                $stmt->bindParam(':nama', $nama);
                $stmt->bindParam(':email', $email);
                $stmt->bindParam(':password', password_hash($password, PASSWORD_DEFAULT));
                $stmt->bindParam(':tanggal_lahir', $tanggal_lahir);
                $stmt->bindParam(':jenis_kelamin', $jenis_kelamin);
                $stmt->bindParam(':alamat', $alamat);
                $stmt->bindParam(':nomor_telepon', $nomor_telepon);
                $stmt->bindParam(':jurusan', $jurusan);
                $stmt->bindParam(':program_studi', $program_studi);
                $stmt->bindParam(':angkatan', $angkatan);
                
                if ($stmt->execute()) {
                    $success = 'Registrasi berhasil! Silakan login dengan akun Anda.';
                } else {
                    $error = 'Gagal melakukan registrasi';
                }
            }
        } catch (Exception $e) {
            $error = 'Terjadi kesalahan sistem: ' . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrasi Mahasiswa - <?php echo APP_NAME; ?></title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(310deg, #7928ca 0%, #ff0080 100%);
            font-family: 'Open Sans', sans-serif;
        }
        .glass-card {
            background: rgba(255, 255, 255, 0.25);
            backdrop-filter: blur(42px);
            border-radius: 1rem;
            border: 1px solid rgba(255, 255, 255, 0.18);
        }
        .form-input {
            background: rgba(255, 255, 255, 0.2);
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 10px;
            padding: 12px 16px;
            color: white;
            transition: all 0.3s ease;
        }
        .form-input::placeholder {
            color: rgba(255, 255, 255, 0.7);
        }
        .form-input:focus {
            background: rgba(255, 255, 255, 0.3);
            border-color: rgba(255, 255, 255, 0.5);
            outline: none;
            box-shadow: 0 0 0 3px rgba(255, 255, 255, 0.1);
        }
        .form-input option {
            background: #7928ca;
            color: white;
        }
        .password-toggle {
            position: absolute;
            right: 12px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: rgba(255, 255, 255, 0.7);
            transition: color 0.3s ease;
        }
        .password-toggle:hover {
            color: white;
        }
    </style>
</head>
<body class="min-h-screen flex items-center justify-center p-4">
    <div class="glass-card w-full max-w-4xl p-8">
        <!-- Header -->
        <div class="text-center mb-8">
            <div class="w-20 h-20 bg-white bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-4">
                <i class="fas fa-user-plus text-white text-3xl"></i>
            </div>
            <h1 class="text-2xl font-bold text-white mb-2">Registrasi Mahasiswa</h1>
            <p class="text-white text-opacity-80">Politeknik Negeri Jakarta</p>
        </div>

        <!-- Registration Form -->
        <form method="POST" class="space-y-6">
            <?php if ($success): ?>
                <div class="bg-green-500 bg-opacity-20 border border-green-400 text-white px-4 py-3 rounded-lg">
                    <div class="flex items-center">
                        <i class="fas fa-check-circle mr-2"></i>
                        <span><?php echo $success; ?></span>
                    </div>
                </div>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="bg-red-500 bg-opacity-20 border border-red-400 text-white px-4 py-3 rounded-lg">
                    <div class="flex items-center">
                        <i class="fas fa-exclamation-circle mr-2"></i>
                        <span><?php echo $error; ?></span>
                    </div>
                </div>
            <?php endif; ?>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <!-- Left Column -->
                <div class="space-y-4">
                    <div>
                        <label for="nim" class="block text-white text-sm font-medium mb-2">
                            <i class="fas fa-id-card mr-2"></i>NIM *
                        </label>
                        <input type="text" id="nim" name="nim" required 
                               class="form-input w-full" placeholder="Masukkan NIM">
                    </div>

                    <div>
                        <label for="nama" class="block text-white text-sm font-medium mb-2">
                            <i class="fas fa-user mr-2"></i>Nama Lengkap *
                        </label>
                        <input type="text" id="nama" name="nama" required 
                               class="form-input w-full" placeholder="Masukkan nama lengkap">
                    </div>

                    <div>
                        <label for="email" class="block text-white text-sm font-medium mb-2">
                            <i class="fas fa-envelope mr-2"></i>Email *
                        </label>
                        <input type="email" id="email" name="email" required 
                               class="form-input w-full" placeholder="Masukkan email">
                    </div>

                    <div>
                        <label for="password" class="block text-white text-sm font-medium mb-2">
                            <i class="fas fa-lock mr-2"></i>Password *
                        </label>
                        <div class="relative">
                            <input type="password" id="password" name="password" required 
                                   class="form-input w-full pr-12" placeholder="Masukkan password">
                            <span class="password-toggle" onclick="togglePassword('password')">
                                <i class="fas fa-eye" id="password-eye"></i>
                            </span>
                        </div>
                    </div>

                    <div>
                        <label for="confirm_password" class="block text-white text-sm font-medium mb-2">
                            <i class="fas fa-lock mr-2"></i>Konfirmasi Password *
                        </label>
                        <div class="relative">
                            <input type="password" id="confirm_password" name="confirm_password" required 
                                   class="form-input w-full pr-12" placeholder="Konfirmasi password">
                            <span class="password-toggle" onclick="togglePassword('confirm_password')">
                                <i class="fas fa-eye" id="confirm_password-eye"></i>
                            </span>
                        </div>
                    </div>

                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label for="tanggal_lahir" class="block text-white text-sm font-medium mb-2">
                                <i class="fas fa-calendar mr-2"></i>Tanggal Lahir
                            </label>
                            <input type="date" id="tanggal_lahir" name="tanggal_lahir" 
                                   class="form-input w-full">
                        </div>
                        <div>
                            <label for="jenis_kelamin" class="block text-white text-sm font-medium mb-2">
                                <i class="fas fa-venus-mars mr-2"></i>Jenis Kelamin
                            </label>
                            <select id="jenis_kelamin" name="jenis_kelamin" class="form-input w-full">
                                <option value="">Pilih</option>
                                <option value="L">Laki-laki</option>
                                <option value="P">Perempuan</option>
                            </select>
                        </div>
                    </div>
                </div>

                <!-- Right Column -->
                <div class="space-y-4">
                    <div>
                        <label for="nomor_telepon" class="block text-white text-sm font-medium mb-2">
                            <i class="fas fa-phone mr-2"></i>Nomor Telepon
                        </label>
                        <input type="tel" id="nomor_telepon" name="nomor_telepon" 
                               class="form-input w-full" placeholder="Masukkan nomor telepon">
                    </div>

                    <div>
                        <label for="alamat" class="block text-white text-sm font-medium mb-2">
                            <i class="fas fa-map-marker-alt mr-2"></i>Alamat
                        </label>
                        <textarea id="alamat" name="alamat" rows="3" 
                                  class="form-input w-full" placeholder="Masukkan alamat"></textarea>
                    </div>

                    <div>
                        <label for="jurusan" class="block text-white text-sm font-medium mb-2">
                            <i class="fas fa-building mr-2"></i>Jurusan *
                        </label>
                        <select id="jurusan" name="jurusan" required class="form-input w-full" onchange="updateProgramStudi()">
                            <option value="">Pilih Jurusan</option>
                            <?php foreach (array_keys($program_studi_options) as $jurusan): ?>
                                <option value="<?php echo $jurusan; ?>"><?php echo $jurusan; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div>
                        <label for="program_studi" class="block text-white text-sm font-medium mb-2">
                            <i class="fas fa-graduation-cap mr-2"></i>Program Studi *
                        </label>
                        <select id="program_studi" name="program_studi" required class="form-input w-full">
                            <option value="">Pilih Program Studi</option>
                        </select>
                    </div>

                    <div>
                        <label for="angkatan" class="block text-white text-sm font-medium mb-2">
                            <i class="fas fa-calendar-alt mr-2"></i>Angkatan *
                        </label>
                        <select id="angkatan" name="angkatan" required class="form-input w-full">
                            <option value="">Pilih Angkatan</option>
                            <?php 
                            $current_year = date('Y');
                            for ($year = $current_year; $year >= $current_year - 10; $year--): 
                            ?>
                                <option value="<?php echo $year; ?>"><?php echo $year; ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                </div>
            </div>

            <div class="flex gap-4">
                <button type="submit" class="flex-1 bg-white bg-opacity-20 hover:bg-opacity-30 text-white font-semibold py-3 px-4 rounded-lg transition-all duration-300 border border-white border-opacity-30">
                    <i class="fas fa-user-plus mr-2"></i>
                    Daftar
                </button>
                <a href="login.php" class="flex-1 text-center bg-transparent border border-white border-opacity-30 text-white py-3 px-4 rounded-lg hover:bg-white hover:bg-opacity-10 transition-all duration-300">
                    <i class="fas fa-arrow-left mr-2"></i>
                    Kembali ke Login
                </a>
            </div>
        </form>
    </div>

    <script>
        const programStudiOptions = <?php echo json_encode($program_studi_options); ?>;

        function updateProgramStudi() {
            const jurusan = document.getElementById('jurusan').value;
            const programStudiSelect = document.getElementById('program_studi');
            
            // Clear existing options
            programStudiSelect.innerHTML = '<option value="">Pilih Program Studi</option>';
            
            if (jurusan && programStudiOptions[jurusan]) {
                programStudiOptions[jurusan].forEach(function(prodi) {
                    const option = document.createElement('option');
                    option.value = prodi;
                    option.textContent = prodi;
                    programStudiSelect.appendChild(option);
                });
            }
        }

        function togglePassword(inputId) {
            const input = document.getElementById(inputId);
            const eye = document.getElementById(inputId + '-eye');
            
            if (input.type === 'password') {
                input.type = 'text';
                eye.classList.remove('fa-eye');
                eye.classList.add('fa-eye-slash');
            } else {
                input.type = 'password';
                eye.classList.remove('fa-eye-slash');
                eye.classList.add('fa-eye');
            }
        }
    </script>
</body>
</html>
