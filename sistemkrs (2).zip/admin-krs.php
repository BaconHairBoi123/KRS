<?php
require_once __DIR__ . '/config/config.php';
requireLogin();

// Check if user is admin
$user_role = getUserRole();
if ($user_role !== 'admin') {
    header('Location: dashboard.php');
    exit();
}

$success = '';
$error = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'toggle_krs':
                try {
                    $new_status = $_POST['krs_status'];
                    $stmt = $pdo->prepare("UPDATE system_settings SET setting_value = ? WHERE setting_key = 'krs_open'");
                    if ($stmt->execute([$new_status])) {
                        $success = 'Status KRS berhasil diubah';
                    }
                } catch (PDOException $e) {
                    $error = 'Error: ' . $e->getMessage();
                }
                break;
                
            case 'approve_krs':
                try {
                    $krs_id = $_POST['krs_id'];
                    $stmt = $pdo->prepare("UPDATE krs SET status = 'disetujui' WHERE id = ?");
                    if ($stmt->execute([$krs_id])) {
                        $success = 'KRS berhasil disetujui';
                    }
                } catch (PDOException $e) {
                    $error = 'Error: ' . $e->getMessage();
                }
                break;
                
            case 'reject_krs':
                try {
                    $krs_id = $_POST['krs_id'];
                    $stmt = $pdo->prepare("UPDATE krs SET status = 'ditolak' WHERE id = ?");
                    if ($stmt->execute([$krs_id])) {
                        $success = 'KRS berhasil ditolak';
                    }
                } catch (PDOException $e) {
                    $error = 'Error: ' . $e->getMessage();
                }
                break;
        }
    }
}

// Get KRS status
try {
    $stmt = $pdo->prepare("SELECT setting_value FROM system_settings WHERE setting_key = 'krs_open'");
    $stmt->execute();
    $krs_status = $stmt->fetchColumn() ?: '0';
} catch (PDOException $e) {
    $krs_status = '0';
}

// Get all KRS data
try {
    $stmt = $pdo->prepare("
        SELECT k.*, m.nim, m.nama as nama_mahasiswa, mk.nama as nama_matakuliah, mk.kode as kode_matakuliah, mk.sks,
               kl.kode_kelas, d.nama as nama_dosen
        FROM krs k
        JOIN mahasiswa m ON k.mahasiswa_id = m.id
        JOIN kelas kl ON k.kelas_id = kl.id
        JOIN mata_kuliah mk ON kl.mata_kuliah_id = mk.id
        JOIN dosen d ON kl.dosen_id = d.id
        ORDER BY k.created_at DESC
    ");
    $stmt->execute();
    $krs_data = $stmt->fetchAll();
} catch (PDOException $e) {
    $krs_data = [];
    $error = 'Error mengambil data KRS: ' . $e->getMessage();
}

// Get statistics
try {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM krs WHERE status = 'pending'");
    $stmt->execute();
    $pending_count = $stmt->fetchColumn();
    
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM krs WHERE status = 'disetujui'");
    $stmt->execute();
    $approved_count = $stmt->fetchColumn();
    
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM krs WHERE status = 'ditolak'");
    $stmt->execute();
    $rejected_count = $stmt->fetchColumn();
} catch (PDOException $e) {
    $pending_count = $approved_count = $rejected_count = 0;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin KRS - Sistem KRS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container-fluid">
            <a class="navbar-brand" href="dashboard-admin.php">
                <i class="fas fa-graduation-cap me-2"></i>Admin KRS
            </a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="dashboard-admin.php">Dashboard</a>
                <a class="nav-link" href="logout.php">Logout</a>
            </div>
        </div>
    </nav>

    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col-12">
                <h2><i class="fas fa-clipboard-list me-2"></i>Manajemen KRS</h2>
                
                <?php if ($success): ?>
                    <div class="alert alert-success alert-dismissible fade show">
                        <i class="fas fa-check-circle me-2"></i><?php echo $success; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <?php if ($error): ?>
                    <div class="alert alert-danger alert-dismissible fade show">
                        <i class="fas fa-exclamation-triangle me-2"></i><?php echo $error; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <!-- KRS Status Control -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5><i class="fas fa-toggle-on me-2"></i>Kontrol Status KRS</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" class="d-inline">
                            <input type="hidden" name="action" value="toggle_krs">
                            <div class="row align-items-center">
                                <div class="col-md-6">
                                    <label class="form-label">Status Periode KRS:</label>
                                    <select name="krs_status" class="form-select">
                                        <option value="0" <?php echo $krs_status == '0' ? 'selected' : ''; ?>>Tutup</option>
                                        <option value="1" <?php echo $krs_status == '1' ? 'selected' : ''; ?>>Buka</option>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-save me-2"></i>Update Status
                                    </button>
                                </div>
                            </div>
                        </form>
                        <div class="mt-2">
                            <span class="badge <?php echo $krs_status == '1' ? 'bg-success' : 'bg-danger'; ?> fs-6">
                                Status: <?php echo $krs_status == '1' ? 'BUKA' : 'TUTUP'; ?>
                            </span>
                        </div>
                    </div>
                </div>

                <!-- Statistics -->
                <div class="row mb-4">
                    <div class="col-md-4">
                        <div class="card bg-warning text-white">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h4><?php echo $pending_count; ?></h4>
                                        <p>Pending</p>
                                    </div>
                                    <div class="align-self-center">
                                        <i class="fas fa-clock fa-2x"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card bg-success text-white">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h4><?php echo $approved_count; ?></h4>
                                        <p>Disetujui</p>
                                    </div>
                                    <div class="align-self-center">
                                        <i class="fas fa-check fa-2x"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card bg-danger text-white">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h4><?php echo $rejected_count; ?></h4>
                                        <p>Ditolak</p>
                                    </div>
                                    <div class="align-self-center">
                                        <i class="fas fa-times fa-2x"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- KRS Data Table -->
                <div class="card">
                    <div class="card-header">
                        <h5><i class="fas fa-table me-2"></i>Data KRS</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead class="table-dark">
                                    <tr>
                                        <th>No</th>
                                        <th>NIM</th>
                                        <th>Nama Mahasiswa</th>
                                        <th>Mata Kuliah</th>
                                        <th>Kelas</th>
                                        <th>Dosen</th>
                                        <th>SKS</th>
                                        <th>Status</th>
                                        <th>Tanggal</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($krs_data)): ?>
                                        <tr>
                                            <td colspan="10" class="text-center">Tidak ada data KRS</td>
                                        </tr>
                                    <?php else: ?>
                                        <?php foreach ($krs_data as $index => $krs): ?>
                                            <tr>
                                                <td><?php echo $index + 1; ?></td>
                                                <td><?php echo htmlspecialchars($krs['nim']); ?></td>
                                                <td><?php echo htmlspecialchars($krs['nama_mahasiswa']); ?></td>
                                                <td>
                                                    <?php echo htmlspecialchars($krs['kode_matakuliah']); ?> - 
                                                    <?php echo htmlspecialchars($krs['nama_matakuliah']); ?>
                                                </td>
                                                <td><?php echo htmlspecialchars($krs['kode_kelas']); ?></td>
                                                <td><?php echo htmlspecialchars($krs['nama_dosen']); ?></td>
                                                <td><?php echo $krs['sks']; ?></td>
                                                <td>
                                                    <?php
                                                    $status_class = '';
                                                    switch ($krs['status']) {
                                                        case 'pending':
                                                            $status_class = 'bg-warning';
                                                            break;
                                                        case 'disetujui':
                                                            $status_class = 'bg-success';
                                                            break;
                                                        case 'ditolak':
                                                            $status_class = 'bg-danger';
                                                            break;
                                                    }
                                                    ?>
                                                    <span class="badge <?php echo $status_class; ?>">
                                                        <?php echo ucfirst($krs['status']); ?>
                                                    </span>
                                                </td>
                                                <td><?php echo date('d/m/Y H:i', strtotime($krs['created_at'])); ?></td>
                                                <td>
                                                    <?php if ($krs['status'] == 'pending'): ?>
                                                        <form method="POST" class="d-inline">
                                                            <input type="hidden" name="action" value="approve_krs">
                                                            <input type="hidden" name="krs_id" value="<?php echo $krs['id']; ?>">
                                                            <button type="submit" class="btn btn-success btn-sm" 
                                                                    onclick="return confirm('Setujui KRS ini?')">
                                                                <i class="fas fa-check"></i>
                                                            </button>
                                                        </form>
                                                        <form method="POST" class="d-inline">
                                                            <input type="hidden" name="action" value="reject_krs">
                                                            <input type="hidden" name="krs_id" value="<?php echo $krs['id']; ?>">
                                                            <button type="submit" class="btn btn-danger btn-sm" 
                                                                    onclick="return confirm('Tolak KRS ini?')">
                                                                <i class="fas fa-times"></i>
                                                            </button>
                                                        </form>
                                                    <?php else: ?>
                                                        <span class="text-muted">-</span>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
