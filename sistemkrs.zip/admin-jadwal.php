<?php
require_once __DIR__ . '/config/config.php';
requireLogin();

if (getUserRole() != 'admin') {
    redirect('dashboard.php');
}

$database = new Database();
$conn = $database->getConnection();

$success = '';
$error = '';

// Handle actions
if ($_POST && isset($_POST['action'])) {
    if ($_POST['action'] == 'add_kelas') {
        try {
            $query = "INSERT INTO kelas (nama_kelas, id_matakuliah, id_dosen, kapasitas, semester, tahun_ajaran, hari, jam_mulai, jam_selesai, ruangan, status) 
                     VALUES (:nama_kelas, :id_matakuliah, :id_dosen, :kapasitas, :semester, :tahun_ajaran, :hari, :jam_mulai, :jam_selesai, :ruangan, :status)";
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':nama_kelas', $_POST['nama_kelas']);
            $stmt->bindParam(':id_matakuliah', $_POST['id_matakuliah']);
            $stmt->bindParam(':id_dosen', $_POST['id_dosen']);
            $stmt->bindParam(':kapasitas', $_POST['kapasitas']);
            $stmt->bindParam(':semester', $_POST['semester']);
            $stmt->bindParam(':tahun_ajaran', $_POST['tahun_ajaran']);
            $stmt->bindParam(':hari', $_POST['hari']);
            $stmt->bindParam(':jam_mulai', $_POST['jam_mulai']);
            $stmt->bindParam(':jam_selesai', $_POST['jam_selesai']);
            $stmt->bindParam(':ruangan', $_POST['ruangan']);
            $stmt->bindParam(':status', $_POST['status']);
            $stmt->execute();
            
            $success = "Kelas berhasil ditambahkan";
        } catch (Exception $e) {
            $error = "Gagal menambahkan kelas: " . $e->getMessage();
        }
    }
    
    if ($_POST['action'] == 'edit_kelas') {
        try {
            $query = "UPDATE kelas SET 
                     nama_kelas = :nama_kelas, id_matakuliah = :id_matakuliah, id_dosen = :id_dosen,
                     kapasitas = :kapasitas, semester = :semester, tahun_ajaran = :tahun_ajaran,
                     hari = :hari, jam_mulai = :jam_mulai, jam_selesai = :jam_selesai,
                     ruangan = :ruangan, status = :status
                     WHERE id_kelas = :id";
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':nama_kelas', $_POST['nama_kelas']);
            $stmt->bindParam(':id_matakuliah', $_POST['id_matakuliah']);
            $stmt->bindParam(':id_dosen', $_POST['id_dosen']);
            $stmt->bindParam(':kapasitas', $_POST['kapasitas']);
            $stmt->bindParam(':semester', $_POST['semester']);
            $stmt->bindParam(':tahun_ajaran', $_POST['tahun_ajaran']);
            $stmt->bindParam(':hari', $_POST['hari']);
            $stmt->bindParam(':jam_mulai', $_POST['jam_mulai']);
            $stmt->bindParam(':jam_selesai', $_POST['jam_selesai']);
            $stmt->bindParam(':ruangan', $_POST['ruangan']);
            $stmt->bindParam(':status', $_POST['status']);
            $stmt->bindParam(':id', $_POST['kelas_id']);
            $stmt->execute();
            
            $success = "Kelas berhasil diupdate";
        } catch (Exception $e) {
            $error = "Gagal mengupdate kelas: " . $e->getMessage();
        }
    }
    
    if ($_POST['action'] == 'delete_kelas') {
        try {
            $query = "DELETE FROM kelas WHERE id_kelas = :id";
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':id', $_POST['kelas_id']);
            $stmt->execute();
            
            $success = "Kelas berhasil dihapus";
        } catch (Exception $e) {
            $error = "Gagal menghapus kelas: " . $e->getMessage();
        }
    }
}

// Get search and filter parameters
$search = $_GET['search'] ?? '';
$semester = $_GET['semester'] ?? '';
$tahun_ajaran = $_GET['tahun_ajaran'] ?? '';
$hari = $_GET['hari'] ?? '';
$status = $_GET['status'] ?? '';

// Pagination
$page = $_GET['page'] ?? 1;
$limit = 15;
$offset = ($page - 1) * $limit;

// Build query with filters
$where_conditions = [];
$params = [];

if (!empty($search)) {
    $where_conditions[] = "(k.nama_kelas LIKE :search OR mk.nama_matakuliah LIKE :search OR d.nama_dosen LIKE :search OR k.ruangan LIKE :search)";
    $params[':search'] = "%$search%";
}

if (!empty($semester)) {
    $where_conditions[] = "k.semester = :semester";
    $params[':semester'] = $semester;
}

if (!empty($tahun_ajaran)) {
    $where_conditions[] = "k.tahun_ajaran = :tahun_ajaran";
    $params[':tahun_ajaran'] = $tahun_ajaran;
}

if (!empty($hari)) {
    $where_conditions[] = "k.hari = :hari";
    $params[':hari'] = $hari;
}

if (!empty($status)) {
    $where_conditions[] = "k.status = :status";
    $params[':status'] = $status;
}

$where_clause = !empty($where_conditions) ? 'WHERE ' . implode(' AND ', $where_conditions) : '';

// Get total count
$count_query = "SELECT COUNT(*) FROM kelas k 
                LEFT JOIN mata_kuliah mk ON k.id_matakuliah = mk.id_matakuliah
                LEFT JOIN dosen d ON k.id_dosen = d.id_dosen
                $where_clause";
$count_stmt = $conn->prepare($count_query);
foreach ($params as $key => $value) {
    $count_stmt->bindValue($key, $value);
}
$count_stmt->execute();
$total_records = $count_stmt->fetchColumn();
$total_pages = ceil($total_records / $limit);

// Get kelas data
$query = "SELECT k.*, mk.nama_matakuliah, mk.kode_matakuliah, mk.sks, d.nama_dosen,
                 COUNT(krs.id_krs) as jumlah_mahasiswa
          FROM kelas k 
          LEFT JOIN mata_kuliah mk ON k.id_matakuliah = mk.id_matakuliah
          LEFT JOIN dosen d ON k.id_dosen = d.id_dosen
          LEFT JOIN krs ON k.id_kelas = krs.id_kelas
          $where_clause 
          GROUP BY k.id_kelas
          ORDER BY k.hari, k.jam_mulai 
          LIMIT :limit OFFSET :offset";
$stmt = $conn->prepare($query);
foreach ($params as $key => $value) {
    $stmt->bindValue($key, $value);
}
$stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$kelas_list = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get mata kuliah list
$mk_query = "SELECT id_matakuliah, nama_matakuliah, kode_matakuliah, sks FROM mata_kuliah WHERE status = 'aktif' ORDER BY nama_matakuliah";
$mk_stmt = $conn->prepare($mk_query);
$mk_stmt->execute();
$matakuliah_list = $mk_stmt->fetchAll(PDO::FETCH_ASSOC);

// Get dosen list
$dosen_query = "SELECT id_dosen, nama_dosen, program_studi FROM dosen WHERE status = 'aktif' ORDER BY nama_dosen";
$dosen_stmt = $conn->prepare($dosen_query);
$dosen_stmt->execute();
$dosen_list = $dosen_stmt->fetchAll(PDO::FETCH_ASSOC);

// Get unique values for filters
$semester_query = "SELECT DISTINCT semester FROM kelas ORDER BY semester";
$semester_stmt = $conn->prepare($semester_query);
$semester_stmt->execute();
$semester_list = $semester_stmt->fetchAll(PDO::FETCH_COLUMN);

$tahun_query = "SELECT DISTINCT tahun_ajaran FROM kelas ORDER BY tahun_ajaran DESC";
$tahun_stmt = $conn->prepare($tahun_query);
$tahun_stmt->execute();
$tahun_list = $tahun_stmt->fetchAll(PDO::FETCH_COLUMN);
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Penjadwalan Perkuliahan - <?php echo APP_NAME; ?></title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
    body {
        background: linear-gradient(310deg, #f0f2f5 0%, #fcfcfc 100%);
        font-family: 'Open Sans', sans-serif;
    }

    .sidebar-soft {
        background: rgba(255, 255, 255, 0.8);
        backdrop-filter: blur(42px);
        border-radius: 1rem;
        border: 1px solid rgba(255, 255, 255, 0.05);
    }

    .nav-link-soft {
        border-radius: 0.5rem;
        margin: 0.125rem 0.5rem;
        padding: 0.65rem 1rem;
        transition: all 0.15s ease-in;
    }

    .nav-link-soft:hover {
        background: rgba(255, 255, 255, 0.2);
    }

    .nav-link-soft.active {
        background: linear-gradient(310deg, #7928ca 0%, #ff0080 100%);
        color: white;
        box-shadow: 0 4px 7px -1px rgba(0, 0, 0, 0.11);
    }

    .card {
        background: #fff;
        border-radius: 1rem;
        box-shadow: 0 20px 27px 0 rgba(0, 0, 0, 0.05);
        border: 0;
    }

    .bg-gradient-primary {
        background: linear-gradient(310deg, #7928ca 0%, #ff0080 100%);
    }

    .form-input {
        border: 1px solid #e0e0e0;
        border-radius: 10px;
        padding: 12px 16px;
        transition: all 0.3s ease;
    }

    .form-input:focus {
        border-color: #7928ca;
        box-shadow: 0 0 0 3px rgba(121, 40, 202, 0.1);
        outline: none;
    }
    </style>
</head>

<body class="bg-gray-50">
    <div class="flex min-h-screen">
        <!-- Sidebar -->
        <div class="w-64 p-4">
            <div class="sidebar-soft h-full p-4">
                <!-- Logo -->
                <div class="flex items-center gap-3 mb-8">
                    <div class="w-10 h-10 bg-gradient-primary rounded-xl flex items-center justify-center">
                        <i class="fas fa-graduation-cap text-white"></i>
                    </div>
                    <div>
                        <h2 class="text-lg font-bold text-gray-800">Admin Panel</h2>
                        <p class="text-xs text-gray-500">Politeknik Negeri Jakarta</p>
                    </div>
                </div>

                <!-- Navigation -->
                <nav class="space-y-2">
                    <div class="px-3 py-2">
                        <p class="text-xs font-semibold text-gray-400 uppercase tracking-wider">Menu Utama</p>
                    </div>

                    <a href="dashboard.php" class="nav-link-soft flex items-center text-gray-700 hover:text-gray-900">
                        <i class="fas fa-home w-5 mr-3"></i>
                        <span>Dashboard</span>
                    </a>

                    <div class="px-3 py-2 mt-6">
                        <p class="text-xs font-semibold text-gray-400 uppercase tracking-wider">Manajemen Pengguna</p>
                    </div>

                    <a href="admin-users.php" class="nav-link-soft flex items-center text-gray-700 hover:text-gray-900">
                        <i class="fas fa-users-cog w-5 mr-3"></i>
                        <span>Kelola Pengguna</span>
                    </a>

                    <a href="admin-mahasiswa.php"
                        class="nav-link-soft flex items-center text-gray-700 hover:text-gray-900">
                        <i class="fas fa-users w-5 mr-3"></i>
                        <span>Data Mahasiswa</span>
                    </a>

                    <a href="admin-dosen.php" class="nav-link-soft flex items-center text-gray-700 hover:text-gray-900">
                        <i class="fas fa-chalkboard-teacher w-5 mr-3"></i>
                        <span>Data Dosen</span>
                    </a>

                    <div class="px-3 py-2 mt-6">
                        <p class="text-xs font-semibold text-gray-400 uppercase tracking-wider">Akademik</p>
                    </div>

                    <a href="admin-matakuliah.php"
                        class="nav-link-soft flex items-center text-gray-700 hover:text-gray-900">
                        <i class="fas fa-book w-5 mr-3"></i>
                        <span>Mata Kuliah</span>
                    </a>

                    <a href="admin-jadwal.php" class="nav-link-soft active flex items-center text-white">
                        <i class="fas fa-calendar w-5 mr-3"></i>
                        <span>Penjadwalan</span>
                    </a>

                    <a href="admin-krs.php" class="nav-link-soft flex items-center text-gray-700 hover:text-gray-900">
                        <i class="fas fa-clipboard-list w-5 mr-3"></i>
                        <span>Manajemen KRS</span>
                    </a>

                    <div class="px-3 py-2 mt-6">
                        <p class="text-xs font-semibold text-gray-400 uppercase tracking-wider">Sistem</p>
                    </div>

                    <a href="admin-laporan.php"
                        class="nav-link-soft flex items-center text-gray-700 hover:text-gray-900">
                        <i class="fas fa-chart-bar w-5 mr-3"></i>
                        <span>Laporan</span>
                    </a>

                    <a href="admin-settings.php"
                        class="nav-link-soft flex items-center text-gray-700 hover:text-gray-900">
                        <i class="fas fa-cog w-5 mr-3"></i>
                        <span>Pengaturan</span>
                    </a>
                </nav>

                <!-- User Info -->
                <div class="absolute bottom-4 left-4 right-4">
                    <div class="bg-white bg-opacity-50 rounded-xl p-3">
                        <div class="flex items-center gap-3">
                            <div class="w-8 h-8 bg-gradient-primary rounded-lg flex items-center justify-center">
                                <i class="fas fa-user-shield text-white text-sm"></i>
                            </div>
                            <div class="flex-1 min-w-0">
                                <p class="text-sm font-medium text-gray-800 truncate"><?php echo $_SESSION['nama']; ?>
                                </p>
                                <p class="text-xs text-gray-500">Administrator</p>
                            </div>
                            <a href="logout.php" class="text-red-500 hover:text-red-700">
                                <i class="fas fa-sign-out-alt"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="flex-1 p-4">
            <!-- Header -->
            <div class="card mb-6">
                <div class="p-6">
                    <div class="flex items-center justify-between">
                        <div>
                            <h1 class="text-2xl font-bold text-gray-800">Penjadwalan Perkuliahan</h1>
                            <p class="text-gray-600">Kelola jadwal kuliah dan assign dosen pengajar</p>
                        </div>
                        <button onclick="openAddModal()"
                            class="bg-purple-600 text-white px-6 py-3 rounded-xl hover:bg-purple-700 transition-colors">
                            <i class="fas fa-plus mr-2"></i>
                            Tambah Kelas
                        </button>
                    </div>
                </div>
            </div>

            <!-- Alerts -->
            <?php if ($success): ?>
            <div class="bg-green-50 border-
