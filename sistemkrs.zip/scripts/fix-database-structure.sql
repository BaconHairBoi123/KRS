-- Fix database structure for missing columns
USE sistem_krs;

-- Add missing columns to tables if they don't exist

-- Add status column to mahasiswa table if it doesn't exist
ALTER TABLE mahasiswa 
ADD COLUMN IF NOT EXISTS status ENUM('aktif', 'nonaktif', 'cuti', 'lulus') DEFAULT 'aktif';

-- Add status column to dosen table if it doesn't exist
ALTER TABLE dosen 
ADD COLUMN IF NOT EXISTS status ENUM('aktif', 'nonaktif') DEFAULT 'aktif';

-- Add status column to mata_kuliah table if it doesn't exist
ALTER TABLE mata_kuliah 
ADD COLUMN IF NOT EXISTS status ENUM('aktif', 'nonaktif') DEFAULT 'aktif';

-- Add missing columns to kelas table if they don't exist
ALTER TABLE kelas 
ADD COLUMN IF NOT EXISTS hari ENUM('Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu') AFTER ruangan,
ADD COLUMN IF NOT EXISTS jam_mulai TIME AFTER hari,
ADD COLUMN IF NOT EXISTS jam_selesai TIME AFTER jam_mulai,
ADD COLUMN IF NOT EXISTS status ENUM('aktif', 'nonaktif') DEFAULT 'aktif' AFTER jam_selesai;

-- Add missing columns to krs table if they don't exist
ALTER TABLE krs 
ADD COLUMN IF NOT EXISTS status ENUM('pending', 'disetujui', 'ditolak') DEFAULT 'pending';

-- Create system_settings table if it doesn't exist
CREATE TABLE IF NOT EXISTS system_settings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value TEXT,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Insert default KRS setting
INSERT IGNORE INTO system_settings (setting_key, setting_value, description) 
VALUES ('krs_open', '0', 'Status periode KRS (0=tutup, 1=buka)');
