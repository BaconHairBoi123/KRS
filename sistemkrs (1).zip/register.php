<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/includes/auth.php';

// Redirect if already logged in
if (isLoggedIn()) {
    header('Location: dashboard.php');
    exit();
}

$success = '';
$error = '';

// Program Studi berdasarkan Jurusan yang baru
$program_studi = [
    'Akuntansi' => [
        'D2 Administrasi Perpajakan',
        'D3 Akuntansi',
        'D4 Akuntansi Manajerial',
        'D4 Akuntansi Perpajakan'
    ],
    'Administrasi Bisnis' => [
        'D2 Manajemen Operasional Bisnis Digital',
        'D3 Administrasi Bisnis',
        'D4 Manajemen Bisnis Internasional',
        'D4 Bisnis Digital',
        'D4 Bahasa Inggris untuk Komunikasi Bisnis & Profesional'
    ],
    'Pariwisata' => [
        'S2 Terapan Perencanaan Pariwisata',
        'D4 Manajemen Bisnis Pariwisata',
        'D3 Perhotelan',
        'D3 Usaha Perjalanan Wisata'
    ],
    'Teknik Sipil' => [
        'D2 Fondasi, Beton, & Pengaspalan Jalan',
        'D3 Teknik Sipil',
        'D4 Manajemen Proyek Konstruksi',
        'D4 Teknologi Rekayasa Konstruksi Bangunan Gedung',
        'D4 Teknologi Rekayasa Konstruksi Bangunan Air'
    ],
    'Teknik Mesin' => [
        'D2 Teknik Manufaktur Mesin',
        'D3 Teknik Mesin',
        'D3 Teknik Pendingin dan Tata Udara',
        'D4 Teknologi Rekayasa Utilitas',
        'D4 Rekayasa Perancangan Mekanik'
    ],
    'Teknik Elektro' => [
        'D2 Instalasi dan Pemeliharaan Kabel Bertegangan Rendah',
        'D3 Teknik Listrik',
        'D4 Teknik Otomasi',
        'D4 Teknologi Rekayasa Energi Terbarukan'
    ],
    'Teknologi Informasi' => [
        'D2 Administrasi Jaringan Komputer',
        'D3 Manajemen Informatika',
        'D4 Teknologi Rekayasa Perangkat Lunak'
    ]
];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nim = trim($_POST['nim']);
    $nama = trim($_POST['nama']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $jurusan = $_POST['jurusan'];
    $program_studi_selected = $_POST['program_studi'];
    $semester = $_POST['semester'];
    $tahun_masuk = $_POST['tahun_masuk'];
    
    // Validasi
    if (empty($nim) || empty($nama) || empty($email) || empty($password) || 
        empty($jurusan) || empty($program_studi_selected) || empty($semester) || empty($tahun_masuk)) {
        $error = 'Semua field harus diisi';
    } elseif ($password !== $confirm_password) {
        $error = 'Password dan konfirmasi password tidak cocok';
    } elseif (strlen($password) < 6) {
        $error = 'Password minimal 6 karakter';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Format email tidak valid';
    } else {
        try {
            // Cek apakah NIM sudah ada
            $stmt = $pdo->prepare("SELECT id FROM mahasiswa WHERE nim = ?");
            $stmt->execute([$nim]);
            if ($stmt->fetch()) {
                $error = 'NIM sudah terdaftar';
            } else {
                // Cek apakah email sudah ada
                $stmt = $pdo->prepare("SELECT id FROM mahasiswa WHERE email = ?");
                $stmt->execute([$email]);
                if ($stmt->fetch()) {
                    $error = 'Email sudah terdaftar';
                } else {
                    // Insert mahasiswa baru
                    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                    $stmt = $pdo->prepare("INSERT INTO mahasiswa (nim, nama, email, password, jurusan, program_studi, semester, tahun_masuk, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'aktif')");
                    
                    if ($stmt->execute([$nim, $nama, $email, $hashed_password, $jurusan, $program_studi_selected, $semester, $tahun_masuk])) {
                        $success = 'Registrasi berhasil! Silakan login dengan akun Anda.';
                    } else {
                        $error = 'Terjadi kesalahan saat registrasi';
                    }
                }
            }
        } catch (PDOException $e) {
            $error = 'Terjadi kesalahan database: ' . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrasi Mahasiswa - Sistem KRS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px 0;
        }
        .register-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
        }
        .password-toggle {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #6c757d;
            z-index: 10;
        }
        .password-toggle:hover {
            color: #495057;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6">
                <div class="register-card p-5">
                    <div class="text-center mb-4">
                        <i class="fas fa-user-graduate fa-3x text-primary mb-3"></i>
                        <h2 class="fw-bold">Registrasi Mahasiswa</h2>
                        <p class="text-muted">Daftar untuk mengakses Sistem KRS</p>
                    </div>

                    <?php if ($success): ?>
                        <div class="alert alert-success" role="alert">
                            <i class="fas fa-check-circle me-2"></i>
                            <?php echo htmlspecialchars($success); ?>
                            <div class="mt-2">
                                <a href="login.php" class="btn btn-success btn-sm">Login Sekarang</a>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if ($error): ?>
                        <div class="alert alert-danger" role="alert">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            <?php echo htmlspecialchars($error); ?>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="nim" class="form-label">NIM</label>
                                <input type="text" class="form-control" id="nim" name="nim" 
                                       value="<?php echo htmlspecialchars($_POST['nim'] ?? ''); ?>" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="nama" class="form-label">Nama Lengkap</label>
                                <input type="text" class="form-control" id="nama" name="nama" 
                                       value="<?php echo htmlspecialchars($_POST['nama'] ?? ''); ?>" required>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email" 
                                   value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>" required>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="password" class="form-label">Password</label>
                                <div class="position-relative">
                                    <input type="password" class="form-control" id="password" name="password" required>
                                    <span class="password-toggle" onclick="togglePassword('password', 'toggleIcon1')">
                                        <i class="fas fa-eye" id="toggleIcon1"></i>
                                    </span>
                                </div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="confirm_password" class="form-label">Konfirmasi Password</label>
                                <div class="position-relative">
                                    <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                                    <span class="password-toggle" onclick="togglePassword('confirm_password', 'toggleIcon2')">
                                        <i class="fas fa-eye" id="toggleIcon2"></i>
                                    </span>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="jurusan" class="form-label">Jurusan</label>
                                <select class="form-select" id="jurusan" name="jurusan" required onchange="updateProgramStudi()">
                                    <option value="">Pilih Jurusan</option>
                                    <?php foreach ($program_studi as $jurusan => $prodi_list): ?>
                                        <option value="<?php echo $jurusan; ?>" 
                                                <?php echo (($_POST['jurusan'] ?? '') == $jurusan) ? 'selected' : ''; ?>>
                                            <?php echo $jurusan; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="program_studi" class="form-label">Program Studi</label>
                                <select class="form-select" id="program_studi" name="program_studi" required>
                                    <option value="">Pilih Program Studi</option>
                                </select>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="semester" class="form-label">Semester</label>
                                <select class="form-select" id="semester" name="semester" required>
                                    <option value="">Pilih Semester</option>
                                    <?php for ($i = 1; $i <= 8; $i++): ?>
                                        <option value="<?php echo $i; ?>" 
                                                <?php echo (($_POST['semester'] ?? '') == $i) ? 'selected' : ''; ?>>
                                            Semester <?php echo $i; ?>
                                        </option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="tahun_masuk" class="form-label">Tahun Masuk</label>
                                <select class="form-select" id="tahun_masuk" name="tahun_masuk" required>
                                    <option value="">Pilih Tahun Masuk</option>
                                    <?php 
                                    $current_year = date('Y');
                                    for ($year = $current_year; $year >= $current_year - 10; $year--): ?>
                                        <option value="<?php echo $year; ?>" 
                                                <?php echo (($_POST['tahun_masuk'] ?? '') == $year) ? 'selected' : ''; ?>>
                                            <?php echo $year; ?>
                                        </option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary w-100 py-2 mb-3">
                            <i class="fas fa-user-plus me-2"></i>
                            Daftar
                        </button>
                    </form>

                    <div class="text-center">
                        <p class="mb-0">Sudah punya akun? <a href="login.php">Login di sini</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        const programStudiData = <?php echo json_encode($program_studi); ?>;

        function updateProgramStudi() {
            const jurusanSelect = document.getElementById('jurusan');
            const prodiSelect = document.getElementById('program_studi');
            const selectedJurusan = jurusanSelect.value;

            // Clear existing options
            prodiSelect.innerHTML = '<option value="">Pilih Program Studi</option>';

            if (selectedJurusan && programStudiData[selectedJurusan]) {
                programStudiData[selectedJurusan].forEach(function(prodi) {
                    const option = document.createElement('option');
                    option.value = prodi;
                    option.textContent = prodi;
                    prodiSelect.appendChild(option);
                });
            }
        }

        function togglePassword(inputId, iconId) {
            const passwordInput = document.getElementById(inputId);
            const toggleIcon = document.getElementById(iconId);
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                toggleIcon.classList.remove('fa-eye');
                toggleIcon.classList.add('fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                toggleIcon.classList.remove('fa-eye-slash');
                toggleIcon.classList.add('fa-eye');
            }
        }

        // Initialize program studi on page load
        document.addEventListener('DOMContentLoaded', function() {
            updateProgramStudi();
            
            // Set selected program studi if exists
            const selectedProdi = '<?php echo $_POST['program_studi'] ?? ''; ?>';
            if (selectedProdi) {
                setTimeout(function() {
                    document.getElementById('program_studi').value = selectedProdi;
                }, 100);
            }
        });
    </script>
</body>
</html>
