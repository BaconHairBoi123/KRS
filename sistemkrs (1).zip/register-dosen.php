<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/includes/auth.php';

// Redirect if already logged in
if (isLoggedIn()) {
    header('Location: dashboard.php');
    exit();
}

$success = '';
$error = '';

// Program Studi berdasarkan Jurusan yang baru
$program_studi_options = [
    'Akuntansi' => [
        'D2 Administrasi Perpajakan',
        'D3 Akuntansi',
        'D4 Akuntansi Manajerial',
        'D4 Akuntansi Perpajakan'
    ],
    'Administrasi Bisnis' => [
        'D2 Manajemen Operasional Bisnis Digital',
        'D3 Administrasi Bisnis',
        'D4 Manajemen Bisnis Internasional',
        'D4 Bisnis Digital',
        'D4 Bahasa Inggris untuk Komunikasi Bisnis & Profesional'
    ],
    'Pariwisata' => [
        'S2 Terapan Perencanaan Pariwisata',
        'D4 Manajemen Bisnis Pariwisata',
        'D3 Perhotelan',
        'D3 Usaha Perjalanan Wisata'
    ],
    'Teknik Sipil' => [
        'D2 Fondasi, Beton, & Pengaspalan Jalan',
        'D3 Teknik Sipil',
        'D4 Manajemen Proyek Konstruksi',
        'D4 Teknologi Rekayasa Konstruksi Bangunan Gedung',
        'D4 Teknologi Rekayasa Konstruksi Bangunan Air'
    ],
    'Teknik Mesin' => [
        'D2 Teknik Manufaktur Mesin',
        'D3 Teknik Mesin',
        'D3 Teknik Pendingin dan Tata Udara',
        'D4 Teknologi Rekayasa Utilitas',
        'D4 Rekayasa Perancangan Mekanik'
    ],
    'Teknik Elektro' => [
        'D2 Instalasi dan Pemeliharaan Kabel Bertegangan Rendah',
        'D3 Teknik Listrik',
        'D4 Teknik Otomasi',
        'D4 Teknologi Rekayasa Energi Terbarukan'
    ],
    'Teknologi Informasi' => [
        'D2 Administrasi Jaringan Komputer',
        'D3 Manajemen Informatika',
        'D4 Teknologi Rekayasa Perangkat Lunak'
    ]
];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nidn = trim($_POST['nidn']);
    $nama_dosen = trim($_POST['nama_dosen']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $jurusan = $_POST['jurusan'];
    $program_studi_selected = $_POST['program_studi'];
    $gelar = $_POST['gelar'] ?? null;
    $nomor_telepon = $_POST['nomor_telepon'] ?? null;
    $bidang_keahlian = $_POST['bidang_keahlian'] ?? null;
    $jabatan = $_POST['jabatan'];
    $pendidikan = $_POST['pendidikan'];
    
    // Validasi
    if (empty($nidn) || empty($nama_dosen) || empty($email) || empty($password) || 
        empty($confirm_password) || empty($jurusan) || empty($program_studi_selected) || empty($jabatan) || empty($pendidikan)) {
        $error = 'Semua field harus diisi';
    } elseif ($password !== $confirm_password) {
        $error = 'Password dan konfirmasi password tidak cocok';
    } elseif (strlen($password) < 6) {
        $error = 'Password minimal 6 karakter';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Format email tidak valid';
    } else {
        try {
            $database = new Database();
            $conn = $database->getConnection();
            
            // Cek apakah NIDN sudah ada
            $stmt = $conn->prepare("SELECT id FROM dosen WHERE nidn = :nidn");
            $stmt->execute([':nidn' => $nidn]);
            if ($stmt->fetch()) {
                $error = 'NIDN sudah terdaftar';
            } else {
                // Cek apakah email sudah ada
                $stmt = $conn->prepare("SELECT id FROM dosen WHERE email = :email");
                $stmt->execute([':email' => $email]);
                if ($stmt->fetch()) {
                    $error = 'Email sudah terdaftar';
                } else {
                    // Insert dosen baru
                    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                    $insert_query = "INSERT INTO dosen (nidn, nama_dosen, email, password, nomor_telepon, gelar, jurusan, program_studi, bidang_keahlian, jabatan, pendidikan, status, created_at) 
                                   VALUES (:nidn, :nama_dosen, :email, :password, :nomor_telepon, :gelar, :jurusan, :program_studi, :bidang_keahlian, :jabatan, :pendidikan, 'aktif', NOW())";
                    
                    $insert_stmt = $conn->prepare($insert_query);
                    $insert_stmt->bindValue(':nidn', $nidn);
                    $insert_stmt->bindValue(':nama_dosen', $nama_dosen);
                    $insert_stmt->bindValue(':email', $email);
                    $insert_stmt->bindValue(':password', $hashed_password);
                    $insert_stmt->bindValue(':nomor_telepon', $nomor_telepon);
                    $insert_stmt->bindValue(':gelar', $gelar);
                    $insert_stmt->bindValue(':jurusan', $jurusan);
                    $insert_stmt->bindValue(':program_studi', $program_studi_selected);
                    $insert_stmt->bindValue(':bidang_keahlian', $bidang_keahlian);
                    $insert_stmt->bindValue(':jabatan', $jabatan);
                    $insert_stmt->bindValue(':pendidikan', $pendidikan);
                    
                    if ($insert_stmt->execute()) {
                        $success = 'Registrasi berhasil! Silakan login dengan akun Anda.';
                    } else {
                        $error = 'Terjadi kesalahan saat registrasi';
                    }
                }
            }
        } catch (Exception $e) {
            $error = 'Terjadi kesalahan database: ' . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrasi Dosen - Sistem KRS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px 0;
        }
        .register-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
        }
        .password-toggle {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #6c757d;
            z-index: 10;
        }
        .password-toggle:hover {
            color: #495057;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6">
                <div class="register-card p-5">
                    <div class="text-center mb-4">
                        <i class="fas fa-chalkboard-teacher fa-3x text-success mb-3"></i>
                        <h2 class="fw-bold">Registrasi Dosen</h2>
                        <p class="text-muted">Daftar untuk mengakses Sistem KRS</p>
                    </div>

                    <?php if ($success): ?>
                        <div class="alert alert-success" role="alert">
                            <i class="fas fa-check-circle me-2"></i>
                            <?php echo htmlspecialchars($success); ?>
                            <div class="mt-2">
                                <a href="login.php" class="btn btn-success btn-sm">Login Sekarang</a>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if ($error): ?>
                        <div class="alert alert-danger" role="alert">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            <?php echo htmlspecialchars($error); ?>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="nidn" class="form-label">NIDN</label>
                                <input type="text" class="form-control" id="nidn" name="nidn" 
                                       value="<?php echo htmlspecialchars($_POST['nidn'] ?? ''); ?>" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="nama_dosen" class="form-label">Nama Lengkap</label>
                                <input type="text" class="form-control" id="nama_dosen" name="nama_dosen" 
                                       value="<?php echo htmlspecialchars($_POST['nama_dosen'] ?? ''); ?>" required>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email" 
                                   value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>" required>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="password" class="form-label">Password</label>
                                <div class="position-relative">
                                    <input type="password" class="form-control" id="password" name="password" required>
                                    <span class="password-toggle" onclick="togglePassword('password', 'toggleIcon1')">
                                        <i class="fas fa-eye" id="toggleIcon1"></i>
                                    </span>
                                </div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="confirm_password" class="form-label">Konfirmasi Password</label>
                                <div class="position-relative">
                                    <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                                    <span class="password-toggle" onclick="togglePassword('confirm_password', 'toggleIcon2')">
                                        <i class="fas fa-eye" id="toggleIcon2"></i>
                                    </span>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="jurusan" class="form-label">Jurusan</label>
                                <select class="form-select" id="jurusan" name="jurusan" required onchange="updateProgramStudi()">
                                    <option value="">Pilih Jurusan</option>
                                    <?php foreach ($program_studi_options as $jurusan => $prodi_list): ?>
                                        <option value="<?php echo $jurusan; ?>" 
                                                <?php echo (($_POST['jurusan'] ?? '') == $jurusan) ? 'selected' : ''; ?>>
                                            <?php echo $jurusan; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="program_studi" class="form-label">Program Studi</label>
                                <select class="form-select" id="program_studi" name="program_studi" required>
                                    <option value="">Pilih Program Studi</option>
                                </select>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="jabatan" class="form-label">Jabatan</label>
                                <select class="form-select" id="jabatan" name="jabatan" required>
                                    <option value="">Pilih Jabatan</option>
                                    <option value="Asisten Ahli" <?php echo (($_POST['jabatan'] ?? '') == 'Asisten Ahli') ? 'selected' : ''; ?>>Asisten Ahli</option>
                                    <option value="Lektor" <?php echo (($_POST['jabatan'] ?? '') == 'Lektor') ? 'selected' : ''; ?>>Lektor</option>
                                    <option value="Lektor Kepala" <?php echo (($_POST['jabatan'] ?? '') == 'Lektor Kepala') ? 'selected' : ''; ?>>Lektor Kepala</option>
                                    <option value="Profesor" <?php echo (($_POST['jabatan'] ?? '') == 'Profesor') ? 'selected' : ''; ?>>Profesor</option>
                                    <option value="Instruktur" <?php echo (($_POST['jabatan'] ?? '') == 'Instruktur') ? 'selected' : ''; ?>>Instruktur</option>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="pendidikan" class="form-label">Pendidikan Terakhir</label>
                                <select class="form-select" id="pendidikan" name="pendidikan" required>
                                    <option value="">Pilih Pendidikan</option>
                                    <option value="S1" <?php echo (($_POST['pendidikan'] ?? '') == 'S1') ? 'selected' : ''; ?>>S1</option>
                                    <option value="S2" <?php echo (($_POST['pendidikan'] ?? '') == 'S2') ? 'selected' : ''; ?>>S2</option>
                                    <option value="S3" <?php echo (($_POST['pendidikan'] ?? '') == 'S3') ? 'selected' : ''; ?>>S3</option>
                                </select>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="gelar" class="form-label">Gelar</label>
                                <input type="text" class="form-control" id="gelar" name="gelar" 
                                       value="<?php echo htmlspecialchars($_POST['gelar'] ?? ''); ?>">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="nomor_telepon" class="form-label">No. Telepon</label>
                                <input type="tel" class="form-control" id="nomor_telepon" name="nomor_telepon" 
                                       value="<?php echo htmlspecialchars($_POST['nomor_telepon'] ?? ''); ?>">
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="bidang_keahlian" class="form-label">Bidang Keahlian</label>
                            <input type="text" class="form-control" id="bidang_keahlian" name="bidang_keahlian" 
                                   value="<?php echo htmlspecialchars($_POST['bidang_keahlian'] ?? ''); ?>">
                        </div>

                        <button type="submit" class="btn btn-success w-100 py-2 mb-3">
                            <i class="fas fa-user-plus me-2"></i>
                            Daftar
                        </button>
                    </form>

                    <div class="text-center">
                        <p class="mb-0">Sudah punya akun? <a href="login.php">Login di sini</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        const programStudiData = <?php echo json_encode($program_studi_options); ?>;

        function updateProgramStudi() {
            const jurusanSelect = document.getElementById('jurusan');
            const prodiSelect = document.getElementById('program_studi');
            const selectedJurusan = jurusanSelect.value;

            // Clear existing options
            prodiSelect.innerHTML = '<option value="">Pilih Program Studi</option>';

            if (selectedJurusan && programStudiData[selectedJurusan]) {
                programStudiData[selectedJurusan].forEach(function(prodi) {
                    const option = document.createElement('option');
                    option.value = prodi;
                    option.textContent = prodi;
                    prodiSelect.appendChild(option);
                });
            }
        }

        function togglePassword(inputId, iconId) {
            const passwordInput = document.getElementById(inputId);
            const toggleIcon = document.getElementById(iconId);
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                toggleIcon.classList.remove('fa-eye');
                toggleIcon.classList.add('fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                toggleIcon.classList.remove('fa-eye-slash');
                toggleIcon.classList.add('fa-eye');
            }
        }

        // Initialize program studi on page load
        document.addEventListener('DOMContentLoaded', function() {
            updateProgramStudi();
            
            // Set selected program studi if exists
            const selectedProdi = '<?php echo $_POST['program_studi'] ?? ''; ?>';
            if (selectedProdi) {
                setTimeout(function() {
                    document.getElementById('program_studi').value = selectedProdi;
                }, 100);
            }
        });
    </script>
</body>

</html>
