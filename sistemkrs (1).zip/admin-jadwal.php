<?php
require_once __DIR__ . '/config/config.php';
requireLogin();

// Check if user is admin
$user_role = getUserRole();
if ($user_role !== 'admin') {
    header('Location: dashboard.php');
    exit();
}

$success = '';
$error = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add_kelas':
                try {
                    $kode_kelas = trim($_POST['kode_kelas']);
                    $mata_kuliah_id = $_POST['mata_kuliah_id'];
                    $dosen_id = $_POST['dosen_id'];
                    $semester = $_POST['semester'];
                    $tahun_akademik = $_POST['tahun_akademik'];
                    $kapasitas = $_POST['kapasitas'];
                    $ruangan = trim($_POST['ruangan']);
                    $hari = $_POST['hari'];
                    $jam_mulai = $_POST['jam_mulai'];
                    $jam_selesai = $_POST['jam_selesai'];
                    
                    $stmt = $pdo->prepare("INSERT INTO kelas (kode_kelas, mata_kuliah_id, dosen_id, semester, tahun_akademik, kapasitas, ruangan, hari, jam_mulai, jam_selesai) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                    
                    if ($stmt->execute([$kode_kelas, $mata_kuliah_id, $dosen_id, $semester, $tahun_akademik, $kapasitas, $ruangan, $hari, $jam_mulai, $jam_selesai])) {
                        $success = 'Kelas berhasil ditambahkan';
                    }
                } catch (PDOException $e) {
                    $error = 'Error: ' . $e->getMessage();
                }
                break;
                
            case 'delete_kelas':
                try {
                    $kelas_id = $_POST['kelas_id'];
                    $stmt = $pdo->prepare("DELETE FROM kelas WHERE id = ?");
                    if ($stmt->execute([$kelas_id])) {
                        $success = 'Kelas berhasil dihapus';
                    }
                } catch (PDOException $e) {
                    $error = 'Error: ' . $e->getMessage();
                }
                break;
        }
    }
}

// Get all classes with related data
try {
    $stmt = $pdo->prepare("
        SELECT k.*, mk.nama as nama_matakuliah, mk.kode as kode_matakuliah, mk.sks,
               d.nama as nama_dosen, d.nidn
        FROM kelas k
        JOIN mata_kuliah mk ON k.mata_kuliah_id = mk.id
        JOIN dosen d ON k.dosen_id = d.id
        ORDER BY k.hari, k.jam_mulai
    ");
    $stmt->execute();
    $kelas_data = $stmt->fetchAll();
} catch (PDOException $e) {
    $kelas_data = [];
    $error = 'Error mengambil data kelas: ' . $e->getMessage();
}

// Get mata kuliah for dropdown
try {
    $stmt = $pdo->prepare("SELECT id, kode, nama, sks FROM mata_kuliah WHERE status = 'aktif' ORDER BY kode");
    $stmt->execute();
    $mata_kuliah_list = $stmt->fetchAll();
} catch (PDOException $e) {
    $mata_kuliah_list = [];
}

// Get dosen for dropdown
try {
    $stmt = $pdo->prepare("SELECT id, nidn, nama FROM dosen WHERE status = 'aktif' ORDER BY nama");
    $stmt->execute();
    $dosen_list = $stmt->fetchAll();
} catch (PDOException $e) {
    $dosen_list = [];
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Jadwal - Sistem KRS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container-fluid">
            <a class="navbar-brand" href="dashboard-admin.php">
                <i class="fas fa-graduation-cap me-2"></i>Admin Jadwal
            </a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="dashboard-admin.php">Dashboard</a>
                <a class="nav-link" href="logout.php">Logout</a>
            </div>
        </div>
    </nav>

    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col-12">
                <h2><i class="fas fa-calendar-alt me-2"></i>Manajemen Jadwal</h2>
                
                <?php if ($success): ?>
                    <div class="alert alert-success alert-dismissible fade show">
                        <i class="fas fa-check-circle me-2"></i><?php echo $success; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <?php if ($error): ?>
                    <div class="alert alert-danger alert-dismissible fade show">
                        <i class="fas fa-exclamation-triangle me-2"></i><?php echo $error; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <!-- Add New Class Form -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5><i class="fas fa-plus me-2"></i>Tambah Kelas Baru</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <input type="hidden" name="action" value="add_kelas">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="kode_kelas" class="form-label">Kode Kelas</label>
                                    <input type="text" class="form-control" id="kode_kelas" name="kode_kelas" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="mata_kuliah_id" class="form-label">Mata Kuliah</label>
                                    <select class="form-select" id="mata_kuliah_id" name="mata_kuliah_id" required>
                                        <option value="">Pilih Mata Kuliah</option>
                                        <?php foreach ($mata_kuliah_list as $mk): ?>
                                            <option value="<?php echo $mk['id']; ?>">
                                                <?php echo htmlspecialchars($mk['kode'] . ' - ' . $mk['nama'] . ' (' . $mk['sks'] . ' SKS)'); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="dosen_id" class="form-label">Dosen</label>
                                    <select class="form-select" id="dosen_id" name="dosen_id" required>
                                        <option value="">Pilih Dosen</option>
                                        <?php foreach ($dosen_list as $dosen): ?>
                                            <option value="<?php echo $dosen['id']; ?>">
                                                <?php echo htmlspecialchars($dosen['nidn'] . ' - ' . $dosen['nama']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="semester" class="form-label">Semester</label>
                                    <select class="form-select" id="semester" name="semester" required>
                                        <option value="">Pilih Semester</option>
                                        <option value="2024/2025 Ganjil">2024/2025 Ganjil</option>
                                        <option value="2024/2025 Genap">2024/2025 Genap</option>
                                        <option value="2025/2026 Ganjil">2025/2026 Ganjil</option>
                                        <option value="2025/2026 Genap">2025/2026 Genap</option>
                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <label for="tahun_akademik" class="form-label">Tahun Akademik</label>
                                    <select class="form-select" id="tahun_akademik" name="tahun_akademik" required>
                                        <option value="">Pilih Tahun</option>
                                        <option value="2024/2025">2024/2025</option>
                                        <option value="2025/2026">2025/2026</option>
                                        <option value="2026/2027">2026/2027</option>
                                    </select>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label for="kapasitas" class="form-label">Kapasitas</label>
                                    <input type="number" class="form-control" id="kapasitas" name="kapasitas" min="1" max="100" value="40" required>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label for="ruangan" class="form-label">Ruangan</label>
                                    <input type="text" class="form-control" id="ruangan" name="ruangan" required>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <label for="hari" class="form-label">Hari</label>
                                    <select class="form-select" id="hari" name="hari" required>
                                        <option value="">Pilih Hari</option>
                                        <option value="Senin">Senin</option>
                                        <option value="Selasa">Selasa</option>
                                        <option value="Rabu">Rabu</option>
                                        <option value="Kamis">Kamis</option>
                                        <option value="Jumat">Jumat</option>
                                        <option value="Sabtu">Sabtu</option>
                                    </select>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label for="jam_mulai" class="form-label">Jam Mulai</label>
                                    <input type="time" class="form-control" id="jam_mulai" name="jam_mulai" required>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label for="jam_selesai" class="form-label">Jam Selesai</label>
                                    <input type="time" class="form-control" id="jam_selesai" name="jam_selesai" required>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save me-2"></i>Tambah Kelas
                            </button>
                        </form>
                    </div>
                </div>

                <!-- Classes Table -->
                <div class="card">
                    <div class="card-header">
                        <h5><i class="fas fa-table me-2"></i>Daftar Kelas</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead class="table-dark">
                                    <tr>
                                        <th>No</th>
                                        <th>Kode Kelas</th>
                                        <th>Mata Kuliah</th>
                                        <th>Dosen</th>
                                        <th>Semester</th>
                                        <th>Ruangan</th>
                                        <th>Jadwal</th>
                                        <th>Kapasitas</th>
                                        <th>Status</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($kelas_data)): ?>
                                        <tr>
                                            <td colspan="10" class="text-center">Tidak ada data kelas</td>
                                        </tr>
                                    <?php else: ?>
                                        <?php foreach ($kelas_data as $index => $kelas): ?>
                                            <tr>
                                                <td><?php echo $index + 1; ?></td>
                                                <td><?php echo htmlspecialchars($kelas['kode_kelas']); ?></td>
                                                <td>
                                                    <?php echo htmlspecialchars($kelas['kode_matakuliah']); ?> - 
                                                    <?php echo htmlspecialchars($kelas['nama_matakuliah']); ?>
                                                    <br><small class="text-muted"><?php echo $kelas['sks']; ?> SKS</small>
                                                </td>
                                                <td>
                                                    <?php echo htmlspecialchars($kelas['nama_dosen']); ?>
                                                    <br><small class="text-muted"><?php echo htmlspecialchars($kelas['nidn']); ?></small>
                                                </td>
                                                <td><?php echo htmlspecialchars($kelas['semester']); ?></td>
                                                <td><?php echo htmlspecialchars($kelas['ruangan']); ?></td>
                                                <td>
                                                    <?php echo htmlspecialchars($kelas['hari']); ?>
                                                    <br><?php echo date('H:i', strtotime($kelas['jam_mulai'])); ?> - 
                                                    <?php echo date('H:i', strtotime($kelas['jam_selesai'])); ?>
                                                </td>
                                                <td><?php echo $kelas['kapasitas']; ?></td>
                                                <td>
                                                    <span class="badge <?php echo $kelas['status'] == 'aktif' ? 'bg-success' : 'bg-danger'; ?>">
                                                        <?php echo ucfirst($kelas['status']); ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <form method="POST" class="d-inline">
                                                        <input type="hidden" name="action" value="delete_kelas">
                                                        <input type="hidden" name="kelas_id" value="<?php echo $kelas['id']; ?>">
                                                        <button type="submit" class="btn btn-danger btn-sm" 
                                                                onclick="return confirm('Hapus kelas ini?')">
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
