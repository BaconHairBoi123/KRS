-- Complete database structure fix for sistem_krs
USE sistem_krs;

-- Drop and recreate kelas table with proper structure
DROP TABLE IF EXISTS kelas;
CREATE TABLE kelas (
    id INT PRIMARY KEY AUTO_INCREMENT,
    kode_kelas VARCHAR(20) UNIQUE NOT NULL,
    mata_kuliah_id INT NOT NULL,
    dosen_id INT NOT NULL,
    semester VARCHAR(10) NOT NULL,
    tahun_akademik VARCHAR(20) NOT NULL,
    kapasitas INT DEFAULT 40,
    ruangan VARCHAR(50),
    hari ENUM('Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'),
    jam_mulai TIME,
    jam_selesai TIME,
    status ENUM('aktif', 'nonaktif') DEFAULT 'aktif',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (mata_kuliah_id) REFERENCES mata_kuliah(id) ON DELETE CASCADE,
    FOREIGN KEY (dosen_id) REFERENCES dosen(id) ON DELETE CASCADE
);

-- Add missing columns to existing tables
ALTER TABLE mahasiswa 
ADD COLUMN IF NOT EXISTS status ENUM('aktif', 'nonaktif', 'cuti', 'lulus') DEFAULT 'aktif';

ALTER TABLE dosen 
ADD COLUMN IF NOT EXISTS status ENUM('aktif', 'nonaktif') DEFAULT 'aktif';

ALTER TABLE mata_kuliah 
ADD COLUMN IF NOT EXISTS status ENUM('aktif', 'nonaktif') DEFAULT 'aktif';

ALTER TABLE krs 
ADD COLUMN IF NOT EXISTS status ENUM('pending', 'disetujui', 'ditolak') DEFAULT 'pending';

-- Create system_settings table if it doesn't exist
CREATE TABLE IF NOT EXISTS system_settings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value TEXT,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Insert default settings
INSERT IGNORE INTO system_settings (setting_key, setting_value, description) VALUES
('krs_open', '1', 'Status periode KRS (0=tutup, 1=buka)'),
('semester_aktif', '2024/2025 Ganjil', 'Semester yang sedang aktif'),
('tahun_akademik', '2024/2025', 'Tahun akademik aktif');

-- Insert sample data for kelas
INSERT IGNORE INTO kelas (kode_kelas, mata_kuliah_id, dosen_id, semester, tahun_akademik, kapasitas, ruangan, hari, jam_mulai, jam_selesai) VALUES
('MK001-A', 1, 1, '2024/2025 Ganjil', '2024/2025', 40, 'R101', 'Senin', '08:00:00', '10:00:00'),
('MK002-A', 2, 2, '2024/2025 Ganjil', '2024/2025', 35, 'R102', 'Selasa', '10:00:00', '12:00:00');
