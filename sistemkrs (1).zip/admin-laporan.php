<?php
require_once __DIR__ . '/config/config.php';
requireLogin();

// Check if user is admin
$user_role = getUserRole();
if ($user_role !== 'admin') {
    header('Location: dashboard.php');
    exit();
}

$error = '';

// Get filter parameters
$semester_filter = $_GET['semester'] ?? '';
$jurusan_filter = $_GET['jurusan'] ?? '';
$status_filter = $_GET['status'] ?? '';

// Build WHERE clause for filters
$where_conditions = [];
$params = [];

if (!empty($semester_filter)) {
    $where_conditions[] = "m.semester = ?";
    $params[] = $semester_filter;
}

if (!empty($jurusan_filter)) {
    $where_conditions[] = "m.jurusan = ?";
    $params[] = $jurusan_filter;
}

if (!empty($status_filter)) {
    $where_conditions[] = "m.status = ?";
    $params[] = $status_filter;
}

$where_clause = '';
if (!empty($where_conditions)) {
    $where_clause = 'WHERE ' . implode(' AND ', $where_conditions);
}

// Get mahasiswa data with KRS statistics
try {
    $query = "
        SELECT m.*, 
               COUNT(k.id) as total_krs,
               SUM(CASE WHEN k.status = 'disetujui' THEN mk.sks ELSE 0 END) as total_sks_disetujui,
               SUM(CASE WHEN k.status = 'pending' THEN 1 ELSE 0 END) as krs_pending,
               SUM(CASE WHEN k.status = 'disetujui' THEN 1 ELSE 0 END) as krs_disetujui,
               SUM(CASE WHEN k.status = 'ditolak' THEN 1 ELSE 0 END) as krs_ditolak
        FROM mahasiswa m
        LEFT JOIN krs k ON m.id = k.mahasiswa_id
        LEFT JOIN kelas kl ON k.kelas_id = kl.id
        LEFT JOIN mata_kuliah mk ON kl.mata_kuliah_id = mk.id
        $where_clause
        GROUP BY m.id
        ORDER BY m.nama
    ";
    
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $mahasiswa_data = $stmt->fetchAll();
} catch (PDOException $e) {
    $mahasiswa_data = [];
    $error = 'Error mengambil data laporan: ' . $e->getMessage();
}

// Get summary statistics
try {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM mahasiswa WHERE status = 'aktif'");
    $stmt->execute();
    $total_mahasiswa_aktif = $stmt->fetchColumn();
    
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM krs WHERE status = 'pending'");
    $stmt->execute();
    $total_krs_pending = $stmt->fetchColumn();
    
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM krs WHERE status = 'disetujui'");
    $stmt->execute();
    $total_krs_disetujui = $stmt->fetchColumn();
    
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM krs WHERE status = 'ditolak'");
    $stmt->execute();
    $total_krs_ditolak = $stmt->fetchColumn();
} catch (PDOException $e) {
    $total_mahasiswa_aktif = $total_krs_pending = $total_krs_disetujui = $total_krs_ditolak = 0;
}

// Get unique values for filters
try {
    $stmt = $pdo->prepare("SELECT DISTINCT semester FROM mahasiswa ORDER BY semester");
    $stmt->execute();
    $semester_list = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    $stmt = $pdo->prepare("SELECT DISTINCT jurusan FROM mahasiswa ORDER BY jurusan");
    $stmt->execute();
    $jurusan_list = $stmt->fetchAll(PDO::FETCH_COLUMN);
} catch (PDOException $e) {
    $semester_list = $jurusan_list = [];
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Laporan - Sistem KRS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container-fluid">
            <a class="navbar-brand" href="dashboard-admin.php">
                <i class="fas fa-graduation-cap me-2"></i>Admin Laporan
            </a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="dashboard-admin.php">Dashboard</a>
                <a class="nav-link" href="logout.php">Logout</a>
            </div>
        </div>
    </nav>

    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col-12">
                <h2><i class="fas fa-chart-bar me-2"></i>Laporan KRS</h2>
                
                <?php if ($error): ?>
                    <div class="alert alert-danger alert-dismissible fade show">
                        <i class="fas fa-exclamation-triangle me-2"></i><?php echo $error; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <!-- Summary Statistics -->
                <div class="row mb-4">
                    <div class="col-md-3">
                        <div class="card bg-primary text-white">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h4><?php echo $total_mahasiswa_aktif; ?></h4>
                                        <p>Mahasiswa Aktif</p>
                                    </div>
                                    <div class="align-self-center">
                                        <i class="fas fa-users fa-2x"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card bg-warning text-white">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h4><?php echo $total_krs_pending; ?></h4>
                                        <p>KRS Pending</p>
                                    </div>
                                    <div class="align-self-center">
                                        <i class="fas fa-clock fa-2x"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card bg-success text-white">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h4><?php echo $total_krs_disetujui; ?></h4>
                                        <p>KRS Disetujui</p>
                                    </div>
                                    <div class="align-self-center">
                                        <i class="fas fa-check fa-2x"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card bg-danger text-white">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h4><?php echo $total_krs_ditolak; ?></h4>
                                        <p>KRS Ditolak</p>
                                    </div>
                                    <div class="align-self-center">
                                        <i class="fas fa-times fa-2x"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Filters -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5><i class="fas fa-filter me-2"></i>Filter Laporan</h5>
                    </div>
                    <div class="card-body">
                        <form method="GET" class="row g-3">
                            <div class="col-md-3">
                                <label for="semester" class="form-label">Semester</label>
                                <select class="form-select" id="semester" name="semester">
                                    <option value="">Semua Semester</option>
                                    <?php foreach ($semester_list as $semester): ?>
                                        <option value="<?php echo $semester; ?>" 
                                                <?php echo $semester_filter == $semester ? 'selected' : ''; ?>>
                                            Semester <?php echo $semester; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <label for="jurusan" class="form-label">Jurusan</label>
                                <select class="form-select" id="jurusan" name="jurusan">
                                    <option value="">Semua Jurusan</option>
                                    <?php foreach ($jurusan_list as $jurusan): ?>
                                        <option value="<?php echo $jurusan; ?>" 
                                                <?php echo $jurusan_filter == $jurusan ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($jurusan); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <label for="status" class="form-label">Status</label>
                                <select class="form-select" id="status" name="status">
                                    <option value="">Semua Status</option>
                                    <option value="aktif" <?php echo $status_filter == 'aktif' ? 'selected' : ''; ?>>Aktif</option>
                                    <option value="nonaktif" <?php echo $status_filter == 'nonaktif' ? 'selected' : ''; ?>>Non-aktif</option>
                                    <option value="cuti" <?php echo $status_filter == 'cuti' ? 'selected' : ''; ?>>Cuti</option>
                                    <option value="lulus" <?php echo $status_filter == 'lulus' ? 'selected' : ''; ?>>Lulus</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">&nbsp;</label>
                                <div>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-search me-2"></i>Filter
                                    </button>
                                    <a href="admin-laporan.php" class="btn btn-secondary">
                                        <i class="fas fa-refresh me-2"></i>Reset
                                    </a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Report Table -->
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5><i class="fas fa-table me-2"></i>Data Mahasiswa & KRS</h5>
                        <button class="btn btn-success btn-sm" onclick="exportToExcel()">
                            <i class="fas fa-file-excel me-2"></i>Export Excel
                        </button>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover" id="reportTable">
                                <thead class="table-dark">
                                    <tr>
                                        <th>No</th>
                                        <th>NIM</th>
                                        <th>Nama</th>
                                        <th>Jurusan</th>
                                        <th>Program Studi</th>
                                        <th>Semester</th>
                                        <th>Status</th>
                                        <th>Total KRS</th>
                                        <th>SKS Disetujui</th>
                                        <th>Pending</th>
                                        <th>Disetujui</th>
                                        <th>Ditolak</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($mahasiswa_data)): ?>
                                        <tr>
                                            <td colspan="12" class="text-center">Tidak ada data</td>
                                        </tr>
                                    <?php else: ?>
                                        <?php foreach ($mahasiswa_data as $index => $mhs): ?>
                                            <tr>
                                                <td><?php echo $index + 1; ?></td>
                                                <td><?php echo htmlspecialchars($mhs['nim']); ?></td>
                                                <td><?php echo htmlspecialchars($mhs['nama']); ?></td>
                                                <td><?php echo htmlspecialchars($mhs['jurusan']); ?></td>
                                                <td><?php echo htmlspecialchars($mhs['program_studi']); ?></td>
                                                <td><?php echo $mhs['semester']; ?></td>
                                                <td>
                                                    <?php
                                                    $status_class = '';
                                                    switch ($mhs['status']) {
                                                        case 'aktif':
                                                            $status_class = 'bg-success';
                                                            break;
                                                        case 'nonaktif':
                                                            $status_class = 'bg-danger';
                                                            break;
                                                        case 'cuti':
                                                            $status_class = 'bg-warning';
                                                            break;
                                                        case 'lulus':
                                                            $status_class = 'bg-info';
                                                            break;
                                                    }
                                                    ?>
                                                    <span class="badge <?php echo $status_class; ?>">
                                                        <?php echo ucfirst($mhs['status']); ?>
                                                    </span>
                                                </td>
                                                <td><?php echo $mhs['total_krs'] ?: 0; ?></td>
                                                <td><?php echo $mhs['total_sks_disetujui'] ?: 0; ?></td>
                                                <td>
                                                    <?php if ($mhs['krs_pending'] > 0): ?>
                                                        <span class="badge bg-warning"><?php echo $mhs['krs_pending']; ?></span>
                                                    <?php else: ?>
                                                        0
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php if ($mhs['krs_disetujui'] > 0): ?>
                                                        <span class="badge bg-success"><?php echo $mhs['krs_disetujui']; ?></span>
                                                    <?php else: ?>
                                                        0
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php if ($mhs['krs_ditolak'] > 0): ?>
                                                        <span class="badge bg-danger"><?php echo $mhs['krs_ditolak']; ?></span>
                                                    <?php else: ?>
                                                        0
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function exportToExcel() {
            // Simple export to CSV (can be opened in Excel)
            let csv = [];
            let rows = document.querySelectorAll("#reportTable tr");
            
            for (let i = 0; i < rows.length; i++) {
                let row = [], cols = rows[i].querySelectorAll("td, th");
                
                for (let j = 0; j < cols.length; j++) {
                    let cellText = cols[j].innerText.replace(/"/g, '""');
                    row.push('"' + cellText + '"');
                }
                
                csv.push(row.join(","));
            }
            
            let csvFile = new Blob([csv.join("\n")], {type: "text/csv"});
            let downloadLink = document.createElement("a");
            downloadLink.download = "laporan_krs_" + new Date().toISOString().slice(0,10) + ".csv";
            downloadLink.href = window.URL.createObjectURL(csvFile);
            downloadLink.style.display = "none";
            document.body.appendChild(downloadLink);
            downloadLink.click();
            document.body.removeChild(downloadLink);
        }
    </script>
</body>
</html>
